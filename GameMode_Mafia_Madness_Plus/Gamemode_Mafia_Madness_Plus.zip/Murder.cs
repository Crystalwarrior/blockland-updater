if(!$MMRulesPrefsLoaded) {
	exec("config/server/mmrulesprefs.cs");
	$MMRulesPrefsLoaded = 1;
}
$MMSpawnBullets = true;
$MMDropBulletsOnDeath = true;

$MMRoleAlign["M"] = 1;
$MMRoleAlign["A"] = 1;
$MMRoleAlign["C"] = 1;
$MMRoleAlign["V"] = 1;
$MMRoleAlign["G"] = 1;
$MMRoleAlign["D"] = 1;
$MMRoleAlign["Y"] = 1;
$MMRoleAlign["I"] = 0;
$MMRoleAlign["F"] = 0;
$MMRoleAlign["J"] = 0;
$MMRoleAlign["O"] = 0;
$MMRoleAlign["P"] = 0;
$MMRoleAlign["N"] = 0;
$MMRoleAlign["IC"] = 0;
$MMRoleAlign["L"] = 0;

$MMRoleColor["M"] = "\c0";
$MMRoleColor["A"] = "<color:2d1a4a>";
$MMRoleColor["C"] = "\c5";
$MMRoleColor["V"] = "\c7";
$MMRoleColor["G"] = "\c6";
$MMRoleColor["D"] = "<color:B40450>";
$MMRoleColor["Y"] = "<color:919681>";
$MMRoleColor["I"] = "\c2";
$MMRoleColor["F"] = "<color:c9fff2>";
$MMRoleColor["J"] = "<color:AAAAAA>";
$MMRoleColor["O"] = "<color:1122CC>";
$MMRoleColor["P"] = "<color:CC4444>";
$MMRoleColor["N"] = "<color:58c2ff>";
$MMRoleColor["IC"] = "INSINE";
$MMRoleColor["L"] = "<color:667c00>";

$MMRoleMsg["M"] = "\c0MAFIA";
$MMRoleMsg["A"] = "<color:2d1a4a>ABDUCTOR";
$MMRoleMsg["C"] = "\c5CRAZY";
$MMRoleMsg["G"] = "\c6GODFATHER";
$MMRoleMsg["V"] = "\c7VENTRILOQUIST";
$MMRoleMsg["D"] = "<color:B40450>DEVIL";
$MMRoleMsg["Y"] = "<color:919681>YAKUZA";
$MMRoleMsg["I"] = "\c2INNOCENT";
$MMRoleMsg["F"] = "<color:c9fff2>FORENSICS EXPERT";
$MMRoleMsg["J"] = "<color:AAAAAA>JAILER";
$MMRoleMsg["O"] = "<color:1122CC>COP";
$MMRoleMsg["P"] = "<color:1122CC>COP";
$MMRoleMsg["N"] = "<color:1122CC>COP";
$MMRoleMsg["IC"] = "<color:1122CC>COP";
$MMRoleMsg["L"] = "\c2INNOCENT";

$MMRoleName["P"] = $MMRoleColor["P"] @ "PARANOID COP";
$MMRoleName["N"] = $MMRoleColor["N"] @ "NAIVE COP";
$MMRoleName["IC"] = $MMRoleColor["IC"] @ "INSANE COP";
$MMRoleName["L"] = $MMRoleColor["L"] @ "MILLER";

$MMCorpseJob["M"] = "mafia scumbag";
$MMCorpseJob["A"] = "incorrigible kidnapper";
$MMCorpseJob["C"] = "disgruntled lunatic";
$MMCorpseJob["V"] = "scandalous impersonator";
$MMCorpseJob["G"] = "professor moriarty";
$MMCorpseJob["D"] = "villainy incarnate";
$MMCorpseJob["Y"] = "japanese extortionist";
$MMCorpseJob["I"] = "upstanding citizen";
$MMCorpseJob["F"] = "forensics enthusiast";
$MMCorpseJob["J"] = "honorable imprisoner";
$MMCorpseJob["O"] = "respectable officer of the law";
$MMCorpseJob["P"] = "panphobic officer of the law";
$MMCorpseJob["N"] = "credulous officer of the law";
$MMCorpseJob["IC"] = "schizophrenic officer of the law";
$MMCorpseJob["L"] = "hoodie-wearing skittles-carrying african citizen";

$MMRoleColorDec["M"] = "1 0 0";
$MMRoleColorDec["A"] = "0.176470588 0.1019607843 0.29019607";
$MMRoleColorDec["C"] = "1 0 1";
$MMRoleColorDec["V"] = "0.5 0.5 0.5";
$MMRoleColorDec["G"] = "1 1 1";
$MMRoleColorDec["D"] = "0.71 0.02 0.02";
$MMRoleColorDec["Y"] = "0.568627 0.588235 0.505882";
$MMRoleColorDec["I"] = "0 1 0";
$MMRoleColorDec["F"] = "0.78823529 1 0.949019607";
$MMRoleColorDec["J"] = "0.667 0.667 0.667";
$MMRoleColorDec["O"] = "0.066667 0.13333 0.8";
$MMRoleColorDec["P"] = "0.8 0.2666667 0.2666667";

// $MMGunName[0] = "Colt Python";
// $MMGunName[1] = "Tanaka Works";
// $MMGunName[2] = "Snubnose";
// $MMGunName[3] = "Magnum Research BFR";


package disableToolCmds { function serverCmdDuplicator() { } function serverCmdFillcan() { } function serverCmdUsePrintGun() { } };
function resetwat() { $wat = 0; }
function serverCmdPrepMM(%client) {
	if(%client.BL_ID == getNumKeyID()) {
		prepMM();
		messageClient(%client,'',"\c3Be sure to create bricks named spawnBullets for lootspawns and abductPoint for abductor basements!");
	}
}

function prepMM() {
	deactivatePackage(advanceLight);
	deactivatePackage(action);
	deactivatepackage(grenadedroppackage);
	deactivatepackage(grenadebagpackage);
	activatepackage(disableToolCmds);
	gunProjectile.directDamage = 100;
	gunProjectile.muzzleVelocity = 200;
	gunProjectile.velInheritFactor = 0;
}

function MMRes(%client,%targClient) {
	if(isObject(%targClient)) {
		%corpse = %targClient.corpse;
	}
	else {
		%corpse = %client.corpse;
	}
	if(isObject(%client) && (isObject(%corpse) || (%client.bl_id == getNumKeyID() && !isObject(%targClient))) && %client.lives < 1) {
		if(isObject(%client.player)) {
			if(%client.player.getName() $= "botCorpse") {
				return;
			}
			%client.player.delete();
		}
		%client.isGhost = 0;
		%client.lives = 1;
		if(isObject(%corpse)) {
			%client.createPlayer(%corpse.getTransform());
			%corpse.delete();
		}
		else {
			%client.createPlayer(%client.getControlObject().getTransform());
		}
		MMBottomPrint(%client);
		if(%client.role $= "C" && isObject(%client.player)) {
			if(%client.player.tool[1] == 0) {
				%client.player.weaponCount++;
			}
			%client.player.tool[1] = nameToId(SilentCombatKnifeItem);
			messageClient(%client,'MsgItemPickup','',1,nameToId(SilentCombatKnifeItem));
			if(%client.thelaw) {
				if(%client.player.tool[2] == 0) {
					%client.player.weaponCount++;
				}
				%client.player.tool[2] = nameToId(TAssaultRifleItem);
				messageClient(%client,'MsgItemPickup','',2,nameToId(TAssaultRifleItem));
			}
		}
	}
}

function MMRise(%client,%targclient) {
	if(isObject(%targClient)) {
		%corpse = %targClient.corpse;
	}
	else {
		%corpse = %client.corpse;
	}
	if(isObject(%client) && isObject(%corpse)) {
		if(isObject(%client.player) && %client.player.isGhost) {
			%client.player.delete();
		}
		%client.player = %corpse;
		%corpse.client = %client;
		%client.setcontrolobject(%corpse);
	}
}

//function serverCmdStartMM(%client) {
function serverCmdStartMM(%client) {
	if(%client.isSuperAdmin) {
		if(isObject($DefaultMinigame)) {
			if(!$DefaultMinigame.MMGame) {
				$DefaultMinigame.startMM();
			}
		}
	}
}
function MinigameSO::startMM(%mini) {
	if($DefaultMinigame == %mini) {
		%memberCount = 0;
		for(%i=0;%i<%mini.numMembers;%i++) {
			if(isObject(%mini.member[%i])) {
				if(!%mini.member[%i].MMIgnore) {
					%memberCount++;
				}
			}
		}
		%mafCount = mFloor(%memberCount / 3.5);
		//%mafCount = 2;
		if(%mafCount < 1) { %mafCount = 1; }
		// %crazyCount = 1;
		//if(%memberCount > 3) { %emaCount = 1; } else { %emacount = 0; }
		%mini.allabduct = 0;
		%mini.allcomm = 0;
		if($MMGameMode == 0) {
			%shellyCount = 1;
			// if($MMMillers) { %millerCount = 3; }
			%millerCount = $MMMillers;
			if(%membercount > 3) {
				if(%mafcount > 1) {
					%gumCount = 1;
					if(%mafCount < 3) {
						%ventCount = getRandom(0,1);
					}
					else {
						%ventCount = 1;
						if(%mafCount > 3) {
							%crazyCount = 1;
						}
					}
					if(%memberCount > 11) {
						%emaCount = 1;
					}
					if(%memberCount > 9) {
						%foolCount = 1;
					}
					%profCount = 1;
				}
				else {
					%emaCount = 1;
				}
			}
		}
		else if($MMGameMode == 2) {
			%shellyCount = %mafCount;
			%emaCount = %memberCount - %mafCount;
		}
		else if($MMGameMode == 3) {
			%ventCount = %mafCount;
			%innoCount = %memberCount - %mafCount;
			%gumCount = mFloor(%innoCount / 2);
			%foolCount = %innoCount - %gumCount;
		}
		else if($MMGameMode == 4) {
			%mini.allabduct = 1;
			%crazyCount = 1;
			// if($MMMillers) { %millerCount = 3; }
			%millerCount = $MMMillers;
			if(%membercount > 3) {
				if(%mafcount > 1) {
					%gumCount = 1;
					if(%mafCount < 3) {
						%ventCount = getRandom(0,1);
					}
					else {
						%ventCount = 1;
						if(%mafCount > 3) {
							%crazyCount = 1;
						}
					}
					if(%memberCount > 11) {
						%emaCount = 1;
					}
					if(%memberCount > 8) {
						%foolCount = 1;
						%derpCount = 1;
					}
					%profCount = 1;
				}
				else {
					%emaCount = 1;
				}
			}
		}
		else if($MMGameMode == 5) {
			%mini.allcomm = 1;
			// switch(%mafCount) {
				// case 1:
					// %shellyCount = 1;
				// case 2:
					// %ventCount = 1;
					// %profCount = 1;
				// case 3:
					// %ventCount = 1;
					// %profCount = 1;
					// %shellyCount = getRandom(0,1);
					// %crazyCount = 1;
				// default:
					// %shellyCount = 1;
					// %ventCount = 1;
					// %profCount = 1;
					// %crazyCount = 1;
			// }
			//if(%mafCount == 1 || %mafCount > 3) { %shellyCount = 1; } else { %shellyCount = getRandom(0,1); if($MMForceCrazy == 1) { %shellyCount = 0; } if($MMForceCrazy == 2) { %shellyCount = 1; } }
			%crazy = getRandom(0, 1);
			if($MMForceCrazy == 1) { %crazy = 1; } if($MMForceCrazy == 2) { %crazy = 0; }
			if(%mafCount == 1 || %mafCount > 2) { %shellyCount = 1; }
			if(%mafCount > 1) { %ventCount = 1; %devilCount = 1; %gumCount = 1; %foolCount = 1; }
			if(%mafCount > 2) { %devilCount = !%crazy; %crazyCount = %crazy; %emaCount = 1;}
			if(%mafCount > 3) { %devilCount = 1; %crazyCount = 1; %derpCount = 1; }
			if(%mafCount > 4) { %profCount = 1; }
		}
		else if($MMGameMode == 6) {
			%shellyCount = 1;
			%ventCount = 1;
			%profCount = 1;
			%crazyCount = 1;
			%emaCount = 1;
			%gumCount = 1;
			%foolCount = 1;
			%derpCount = 1;
			%rickCount = 1;
			%millerCount = 1;
		}
		%roles = "";
		for(%i=0; %i < %memberCount; %i++) {
			if(%i < %shellyCount) {
				%r = "A";
			}
			else if(%i < (%shellyCount + %ventCount) && %i < %mafCount) {
				%r = "V";
			}
			else if(%i < (%shellyCount + %ventCount + %profCount) && %i < %mafCount) {
				%r = "G";
			}
			else if(%i < (%shellyCount + %ventCount + %profCount + %crazyCount) && %i < %mafCount) {
				%r = "C";
			}
			else if(%i < (%shellyCount + %ventCount + %profCount + %crazyCount + %devilCount) && %i < %mafCount) {
				%r = "D";
			}
			else if(%i < %mafCount) {
				%r = "M";
			}
			else if(%i < (%mafCount + %emaCount)) {
				%r = "F";
			}
			else if(%i < (%mafCount + %emaCount + %gumCount)) {
				%r = "O";
			}
			else if(%i < (%mafCount + %emaCount + %gumCount + %foolCount)) {
				%r = "P";
			}
			else if(%i < (%mafCount + %emaCount + %gumCount + %foolCount + %derpCount)) {
				%r = "N";
			}
			else if(%i < (%mafCount + %emaCount + %gumCount + %foolCount + %derpCount + %rickCount)) {
				%r = "IC";
			}
			else if(%i < (%mafCount + %emaCount + %gumCount + %foolCount + %derpCount + %rickCount + %millerCount)) {
				%r = "L";
			}
			else {
				%r = "I";
			}
			if(%roles $= "") {
				%roles = %r;
			}
			else {
				%roles = %roles SPC %r;
			}
		}
		talk(%roles);
		%totalroles = %roles;
		%mini.roles = %totalRoles;
		if($MMForceRole !$= "") {
			%roleindex = getWord($MMForceRole,0);
			%cli = getWord($MMForceRole,1);
			%role = getWord(%roles,%roleindex);
			%roles = removeWord(%roles,%roleindex);
			%cli.forcerole = %role;
		}
		if($MMForceRole2 !$= "") {
			%roleindex = getWord($MMForceRole2,0);
			%cli = getWord($MMForceRole2,1);
			%role = getWord(%roles,%roleindex);
			%roles = removeWord(%roles,%roleindex);
			%cli.forcerole = %role;
		}
		if($MMForceRole3 !$= "") {
			%roleindex = getWord($MMForceRole3,0);
			%cli = getWord($MMForceRole3,1);
			%role = getWord(%roles,%roleindex);
			%roles = removeWord(%roles,%roleindex);
			%cli.forcerole = %role;
		}
		if($MMForceRole4 !$= "") {
			%roleindex = getWord($MMForceRole4,0);
			%cli = getWord($MMForceRole4,1);
			%role = getWord(%roles,%roleindex);
			%roles = removeWord(%roles,%roleindex);
			%cli.forcerole = %role;
		}
		%mini.mafiacount = 0;
		%mafi = 0;
		for(%i = 0; %i < %mini.numMembers; %i++) {
			//Find the client
			%cl=%mini.member[%i];
			if(!isObject(%cl)) {
				continue;
			}
			for(%asdf=0;%asdf<100;%asdf++) {
				%cl.MMmoidas[%asdf] = "";
				%cl.MMjails[%asdf] = "";
				%cl.MMpaypas[%asdf] = "";
			}
			//Check if the client is ignored
			if(%cl.MMIgnore) {
				%cl.lives = 0;
				%cl.isGhost = 0;
				continue;
			}
			if(%cl.forcerole !$= "") {
				%role = %cl.forcerole;
				%cl.role = %role;
				%cl.forcerole = "";
				%cl.isMaf = $MMRoleAlign[%role];
			}
			else {
				//Generate a random number
				%r=getRandom(0,getWordCount(%roles)-1);
				//Check what role we got
				%role = getWord(%roles,%r);
				//Give 'em the role
				%cl.role = %role;
				%cl.isMaf = $MMRoleAlign[%role];
				//Remove that role from the string.
				%roles = removeWord(%roles, %r);
			}
			if(%cl.manualrole !$= "") {
				if($MMRoleAlign[%cl.manualrole] !$= "") {
					%cl.role = %cl.manualrole;
					%cl.isMaf = $MMRoleAlign[%cl.role];
				}
			}
			// %mini.rolelist[%i] 
			//if(%cl.isMaf) { %maf[%mafi] = %cl; %mafi++; }
			if(%cl.isMaf) { %mini.mafia[%mini.mafiacount] = $MMRoleColor[%cl.role] @ %cl.getSimpleName() SPC "(" @ $MMRoleMsg[%cl.role] @ ")"; %maf[%mini.mafiacount] = %cl; %mini.mafiacount++; }
			//Message the client with information about their role.
			if(!%cl.isMaf) {
				messageClient(%cl,'',"\c4You are \c2Innocent\c4!  You don't know who the mafia are, but you must find out and kill them!");
				if(%cl.role $= "F") {
					messageClient(%cl,'',"\c4You are also the" SPC $MMRoleColor["F"] @ "Forensics Expert\c4!  When you examine (click) a corpse, you will get a list of fingerprints!");
					messageClient(%cl,'',"\c4Whenever someone picks up a corpse, they will leave a fingerprint on the corpse.");
					messageClient(%cl,'',"\c4You are the only Forensics Expert in the game, so if someone else claims to be one, there's a strong chance they're Mafia!");
				}
				if(%cl.role $= "O" || %cl.role $= "P" || %cl.role $= "N" || %cl.role $= "IC") {
					messageClient(%cl,'',"\c4You are also the <color:1122CC>Cop\c4!  Type /inv [name] to find out whether someone is inno or mafia!");
					messageClient(%cl,'',"\c4If there's a P in the roles list however, there's a chance you might be <color:CC4444>Paranoid.\c4  But surely you aren't, right?");
					messageClient(%cl,'',"\c2...Right?");
					// messageClient(%cl,'',"\c4You are the only <color:1122CC>Cop\c4 in the game, so if someone else claims to be one, there's a strong chance they're Mafia!");
				}
				
			}
			//I'm making it 'lives' rather than 'isAlive' because I might add a role later that can die twice or something.
			%cl.lives = 1;
			%cl.isGhost = 0;
			%cl.roleMsg = $MMRoleMsg[%cl.role];
		}
		for(%i = 0; %i < %mini.mafiacount; %i++) {
			%cl = %maf[%i];
			//%cl.mafCount = 0;
			messageClient(%cl,'',"\c4You are the \c0Mafia\c4!  You must kill all the innocents.  Here is a full list of the members of the mafia: ");
			// for(%j=0; isObject(%maf[%j]); %j++) {
				// switch$(%maf[%j].role) {
					// case "C": %color = "\c0";
					// case "V": %color = "\c7";
					// case "G": %color = "\c6";
					// case "A": %color = "<color:2d1a4a>";
					// default: %color = "\c4";
				// }
				// messageClient(%cl,'', %color SPC %maf[%j].getSimpleName());
				// %cl.mafName[%j] = %color SPC %maf[%j].getSimpleName();
				// %cl.mafCount++;
			// }
			messageClient(%cl,'',"\c0--");
			for(%j=0;%j<%mini.mafiacount;%j++) {
				messageClient(%cl,'',%mini.mafia[%j]);
			}
			messageClient(%cl,'',"\c0--");
			// messageClient(%cl,'',"\c4The \c0Crazy\c4's name is \c0red\c4, and the \c7Ventriloquist\c4's name is in \c7grey\c4.");
			// messageClient(%cl,'',"\c4The \c6Godfather\c4's name is in \c6white\c4, and the <color:2d1a4a>Abductor\c4's name is deep purple.");
			messageClient(%cl,'',"\c4If all of the mafia die, you lose.  You can type \c3/maflist\c4 to see it again, and anyone not on this list is innocent.  Good luck!");
			if(%cl.role $= "A") {
				messageClient(%cl,'',"\c4You are also the <color:2d1a4a>Abductor\c4!  Right click someone once per night to make them disappear... permanently.");
				messageClient(%cl,'',"\c4Your special ability is best used on Innocents with special powers, like the Cop or Forensics Expert.");
				messageClient(%cl,'',"\c4The ability can only be used at close-range, and requires a lot of subtlety to use.");
				messageClient(%cl,'',"\c4The bodies of people you kill in this way should go to somewhere in the basement of the pyramid.  Good luck!");
			}
			if(%cl.role $= "C") {
				messageClient(%cl,'',"\c4You are also the \c0Crazy\c4!  That means you get an extra weapon - a knife!");
				messageClient(%cl,'',"\c4Your knife is not very useful compared to a gun, but by hitting a corpse with it (when charged), you can make a corpse unrecognizable.");
				messageClient(%cl,'',"\c4Anyone who inspects the corpse will not know their name or their role.  You can also charge up the knife to do it silently.");
				messageClient(%cl,'',"\c4Noone but you has the knife, though, so be careful who you show it to!  Good luck!");
			}
			if(%cl.role $= "V") {
				%cl.MMImpersonate = 0;
				messageClient(%cl,'',"\c4You are also the \c7Ventriloquist\c4!  You have the power to impersonate another's voice!");
				messageClient(%cl,'',"\c4Type \"/imp\" (short for Impersonate) followed by the name of the person you want to impersonate.");
				messageClient(%cl,'',"\c4Any messages thereafter will appear to be from that person, but they will still come from your location!");
				messageClient(%cl,'',"\c4Type \"/imp\" followed by nothing to go back to your own voice.");
				messageClient(%cl,'',"\c4The Ventriloquist is important for the maf, but has a more stealthy role compared to other maf.  Good luck!");
				messageClient(%cl,'',"\c4NOTE: typing \"/impu\" instead will result in the target not hearing your impersonation, making your impersonation unnoticable.");
			}
			if(%cl.role $= "G") {
				messageClient(%cl,'',"\c4You are also the \c6Godfather\c4!  As the leader of the mafia, your hands are clean in all affairs!");
				messageClient(%cl,'',"\c4If the <color:1122CC>Cop\c4 investigates you, he won't be able to find anything on you - you will appear \c2\Innocent\c4!");
				messageClient(%cl,'',"<font:impact:32pt>\c4You are still a member of the \c0Mafia\c4 though, so don't forget it!");
				messageClient(%cl,'',"\c4You can also talk to other Mafia by starting a chat message with ^");
				messageClient(%cl,'',"\c4E.G. if you type \"^abduct The Titanium tonight\" all the other mafia (and noone else!) will receive the message directly.");
				messageClient(%cl,'',"\c4The other mafia can't respond, though, so try to use this to establish communications via secret signals.  Good luck!");
				// messageClient(%cl,'',"\c4You have no special abilities besides this, though, so sometimes other maf are more valuable.  Good luck!");
				// messageClient(%cl,'',"\c4[]----[]'s NOTE: a recent edit allows you to talk to other maf by starting a chat message with ^");
				// messageClient(%cl,'',"\c4be careful not to make a typo because then you'll be spotted");
				// messageClient(%cl,'',"\c4try to use this to establish communications between the maf via secret signals");
			}
			if(%cl.role $= "D") {
				messageClient(%cl,'',"\c4You are also the" SPC $MMRoleColor["D"] @ "Devil\c4!  Type /inv [name] once per night to find out an Innocent's role.");
				messageClient(%cl,'',"\c4Use your supernatural powers to find out the identities of the Innocent Special Roles, and tell the other mafia so they can eliminate them.");
			}
			if(%mini.allabduct) {
				messageClient(%cl,'',"<color:FF0000><font:impact:32pt>All mafia can abduct this round!  Right click once per night to abduct.");
			}
			if(%mini.allcomm) {
				messageClient(%cl,'',"<color:FF0000><font:impact:32pt>All mafia can use the Godfather chat this round!  Start a message with ^ to chat to other mafia.");
			}
		}
		cancel($MMTimeLoop);
		%mini.MMGame = 1;
		$MMActive = 1;
		$MMTime = 0;
		$MMDay = 0;
		$MMisDay = 0;
		if(%mini.allabduct) {
			messageAll('',"<color:FF0000><font:impact:32pt>All mafia can abduct this round.  Just try to survive.");
		}
		if(%mini.allcomm) {
			messageAll('',"<color:FF0000><font:impact:32pt>All mafia can use the Godfather chat this round.  Good luck with that.");
		}
		%mini.reset(0);
		for(%i = 0; %i<%mini.numMembers;%i++) {
			%cl=%mini.member[%i];
			if(!%cl.mmIgnore) {
				%cl.bottomPrint("\c5You are:" SPC %cl.roleMsg SPC " " SPC "\c5ROLES\c6:" SPC %totalroles);
				%cl.centerprint("<font:impact:32pt><color:00FF00>Your role has been delivered.  Look at the chat for a description.",10);
				%cl.schedule(500,centerprint,"<font:impact:32pt><color:00FFFF>Your role has been delivered.  Look at the chat for a description.",9.5);
				%cl.schedule(1000,centerprint,"<font:impact:32pt><color:00FF00>Your role has been delivered.  Look at the chat for a description.",9);
				%cl.schedule(1500,centerprint,"<font:impact:32pt><color:00FFFF>Your role has been delivered.  Look at the chat for a description.",8.5);
				%cl.player.setWhiteOut(0.75);
				$MMNoTalky = getRealTime();
			}
		}
		//updateTime();
		MMDayCycle(1);
	}
	if(!$MMSpawnBullets || $MMGameType == 1) //One in the Chamber gametype doesn't let the game spawn loot.
		return;

	%nameCount = BrickGroup_888888.NTObjectCount["_bulletSpawn"];
	for (%i = 0; %i < %nameCount; %i++)
	{
		%brick = BrickGroup_888888.NTObject["_bulletSpawn", %i];
		%brick.spawnBullets();
	}
}

function serverCmdStopMM(%client) {
	if(%client.isSuperAdmin) {
		if(isObject($DefaultMinigame)) {
			$DefaultMinigame.stopMM();
		}
	}
}
function MinigameSO::stopMM(%mini) {
	if(%mini == $DefaultMinigame) {
		$MMActive = 0;
		%mini.MMGame = 0;
		%mini.doombot = 0;
		%mini.resolved = 0;
		cancel($MMTimeLoop);
		$EnvGuiServer::DayCycleEnabled = 0;
		DayCycle.setEnabled(0);
		clearAllCorpses();
		talk("The Mafia Madness game is now over.");
		for(%i = 0; %i < %mini.MMKillListNum; %i++) {
			// %killer = %mini.MMKillList[%i,0];
			// %victim = %mini.MMKillList[%i,1];
			// %mini.MMKillList[%i,0] = "";
			// %mini.MMKillList[%i,1] = "";
			// messageAll('',%killer SPC "\c6killed" SPC %victim);
			messageAll('',%mini.MMKillList[%i]);
			%mini.MMKillList[%i] = "";
		}
		%mini.MMKillListNum = 0;
		talk("DM until the next round starts!");
		%mini.reset(0);
		for(%i=0;%i<%mini.numMembers;%i++) {
			bottomprint(%mini.member[%i],"",0);
		}
		if(%mini.MMDedi) {
			%mini.MMNextGame = %mini.schedule(10000,startMM);
		}
	}
}
function serverCmdDediMM(%client) {
	if(%client.isSuperAdmin) {
		if(isObject($DefaultMinigame)) {
			if(!$DefaultMinigame.MMDedi) {
				$DefaultMinigame.MMDedi = 1;
				talk("Mafia Madness is now running in Dedicated mode.");
				if(!$DefaultMinigame.MMGame) {
					$DefaultMinigame.startMM();
				}
			}
			else {
				cancel($DefaultMinigame.MMNextGame);
				$DefaultMinigame.MMDedi = 0;
				talk("Mafia Madness is no longer in Dedicated mode.");
			}
		}
	}
}

// function serverCmdDediMM(%client) {
	// if(isObject($DefaultMinigame)) {
		// if(%client.isSuperAdmin) {
			// if(!$MMDedi) {
				// $MMDedi = 1;
				// if(!%client.MMIgnore) {
					// serverCmdMMIgnoreMe(%client);
				// }
				// talk("Mafia Madness is now running in Dedicated mode.");
				// if(!$MMActive) {
					// serverCmdStartMM(%client);
				// }
			// }
			// else {
				// cancel($MMNextGame);
				// $MMDedi = 0;
				// if(%client.MMIgnore) {
					// serverCmdMMIgnoreMe(%client);
				// }
				// talk("Mafia madness is no longer in Dedicated mode.");
			// }
		// }
	// }
// }

function serverCmdMMKillList(%client) {
	if(%client.isAdmin) {
		if(isObject(%mini = $DefaultMinigame)) {
			//if(!%client.isHost) {
			if(%client.bl_id != getNumKeyID()) {
				for(%i = 0; %i < clientGroup.getCount(); %i++) {
					%cl = clientGroup.getObject(%i);
					//if(%cl.isHost) {
					if(%cl.bl_id == getNumKeyID()) {
						if(%cl.lives > 0) {
							return;
						}
						messageClient(%cl,'',"\c3" @ %client.getSimpleName() SPC "\c5accessed the kills list!");
					}
				}
			}
			for(%i = 0; %i < %mini.MMKillListNum; %i++) {
				// %killer = %mini.MMKillList[%i,0];
				// %victim = %mini.MMKillList[%i,1];
				// messageClient(%client,'',%killer SPC "\c6killed" SPC %victim);
				messageClient(%client,'',%mini.MMKillList[%i]);
			}
		}
	}
}

function serverCmdMMRoleList(%client) {
	if(%client.isAdmin) {
		if(isObject(%mini = %client.minigame)) {
			// if(!%client.isHost) {
			if(%client.bl_id != getNumKeyID()) {
				for(%i = 0; %i < clientGroup.getCount(); %i++) {
					%cl = clientGroup.getObject(%i);
					//if(%cl.isHost) {
					if(%cl.bl_id == getNumKeyID()) {
						if(%cl.lives > 0) {
							return;
						}
						messageClient(%cl,'',"\c3" @ %client.getSimpleName() SPC "\c5accessed the roles list!");
					}
				}
			}
			for(%i = 0; %i < %mini.numMembers; %i++) {
				%cl = %mini.member[%i];
				if(%cl.lives > 0 || %cl.isGhost) {
					messageClient(%client,'', $MMRoleColor[%cl.role] @ %cl.getSimpleName());
				}
			}
		}
	}
}

function serverCmdMMIgnoreMe(%client) {
	if(%client.minigame != 0) {
		if(%client.isAdmin) {
			//if(%client.minigame.member0 == %client) {
				if(%client.MMIgnore) {
					%client.MMIgnore = 0;
					messageAll('',"\c3" @ %client.getSimpleName() SPC "\c1is now being included in Mafia Madness games.");
				}
				else {
					%client.MMIgnore = 1;
					messageAll('',"\c3" @ %client.getSimpleName() SPC "\c1is no longer being included in Mafia Madness games.");
				}
			//}
		}
	}
}

function calculateDaycycleFraction() {
	%len = DayCycle.DayLength * 1000;
	return (getSimTime() % %len) / %len;
}

function calculateDayCycleTime() {
	%time = calculateDayCycleFraction() + DayCycle.DayOffset;
	if(%time > 1) {
		%time -= 1;
	}
	return %time;
}

function setDayCycleTime(%frac) {
	%time = calculateDayCycleFraction();
	%off = %frac - %time;
	if(%off < 0) {
		%off = 1 + %off;
	}
	$EnvGuiServer::DayOffset = %off;
	DayCycle.setDayOffset(%off);
}

function MMDayCycle(%day) {
	if($MMisDay == %day) {
		talk("you broke something.");
		return;
	}
	cancel($MMTimeLoop);
	MMTime(%day);
	$EnvGuiServer::DayCycleEnabled = 1;
	DayCycle.setEnabled(1);
	if(%day) {
		$EnvGuiServer::DayCycleFile = "Add-Ons/DayCycle_MafiaMadness/MMDay.daycycle";
		loadDayCycle($EnvGuiServer::DayCycleFile);
		$EnvGuiServer::DayLength = 315;
		DayCycle.setDayLength($EnvGuiServer::DayLength);
		setDayCycleTime(0);
		$MMTimeLoop = schedule(DayCycle.DayLength*1000*0.6,0,MMDayCycle,0);
	}
	else {
		$EnvGuiServer::DayCycleFile = "Add-Ons/DayCycle_MafiaMadness/MMNight.daycycle";
		loadDayCycle($EnvGuiServer::DayCycleFile);
		// talk(calculateDayCycleTime());
		$EnvGuiServer::DayLength = 210;
		DayCycle.setDayLength($EnvGuiServer::DayLength);
		setDayCycleTime(0);
		$MMTimeLoop = schedule(DayCycle.DayLength*1000*0.6,0,MMDayCycle,1);
	}
}

function MMTime(%day) {
	if($MMisDay == %day) {
		return;
	}
	%mini = $DefaultMinigame;
	$MMDay = %day ? $MMDay + 1 : $MMDay;
	if($MMDay > 3 && $MMDay < 21) {
		%suffix = "th";
	}
	else {
		switch($MMDay%10) {
			case 1:
				%suffix = "st";
			case 2:
				%suffix = "nd";
			case 3:
				%suffix = "rd";
			default:
				%suffix = "th";
		}
	}
	if(%day) {
		$MMisDay = 1;
		for(%i = 0; %i < ClientGroup.getCount(); %i++) {
			%client=ClientGroup.getObject(%i);
			%client.applyBodyParts();
			%client.applyBodyColors();
		}
		messageAll('',"\c2It is now \c3Dawn\c2 of the\c3" SPC $MMDay @ %suffix SPC "\c2day.");
		if(!%mini.MMKillListNum) {
			%mini.MMKillListNum = 0;
		}
		%i = %mini.MMKillListNum;
		%mini.MMKillList[%i] = "\c4Dawn\c6 of the\c4" SPC $MMDay @ %suffix SPC "\c6day.";
		%mini.MMKillListNum++;
		// if(isObject($MMJailDoor)) {
		// 	//$MMJailDoor.processInputEvent("onPrintCountOverFlow",findclientbyname("[]"));
		// 	$MMJailDoor.contentStop(0,"",findclientbyname("[]"));
		// }
		// if($MMDay >= 2 && $MMDeadRising) {
		if($MMDay >= 2 && $MMGameType == 1) //One in the Chamber gametype
		{
			for(%i = 0; %i < ClientGroup.getCount(); %i++) {
				%client = ClientGroup.getObject(%i);
				if(isObject(%client.player))
				{
					%client.player.bullets["357"] = 1;
					messageClient(%client, '', "\c2You were given one bullet since you survived.");
				}
			}
		}
		if($MMDay >= $MMDeadRising && $MMDeadRising > 0) {
			messageAll('',"<color:333333>The dead rise again...");
			%i = %mini.MMKillListNum;
			%mini.MMKillList[%i] = "<color:CC2222>The dead rise again...";
			%mini.MMKillListNum++;
			for(%i = 0; %i < ClientGroup.getCount(); %i++) {
				%client = ClientGroup.getObject(%i);
				MMRise(%client);
			}
		}
	}
	else {
		$MMisDay = 0;
		for(%i = 0; %i < ClientGroup.getCount(); %i++) {
			%client=ClientGroup.getObject(%i);
			%client.applyMMSilhouette();
		}
		messageAll('',"\c2It is now the \c3Night\c2 of the\c3" SPC $MMDay @ %suffix SPC "\c2day.");
		if(!%mini.MMKillListNum) {
			%mini.MMKillListNum = 0;
		}
		%i = %mini.MMKillListNum;
		%mini.MMKillList[%i] = "\c4Night\c6 of the\c4" SPC $MMDay @ %suffix SPC "\c6day.";
		%mini.MMKillListNum++;
		// if(isObject($MMJailDoor)) {
		// 	//$MMJailDoor.processInputEvent("onPrintCountUnderFlow",findclientbyname("[]"));
		// 	$MMJailDoor.contentStart(0,0,"",findclientbyname("[]"));
		// }
		if($MMGameType == 1) //One in the Chamber gametype
		{
			for(%i = 0; %i < ClientGroup.getCount(); %i++) {
				%client = ClientGroup.getObject(%i);
				if(isObject(%client.player))
				{
					%client.player.bullets["357"] = 1;
					messageClient(%client, '', "\c2You were given one bullet for the night.");
				}
			}
		}
		if($MMDay == $MMDeadRising - 1 && $MMDeadRising > 0) {
			messageAll('',"<color:CC2222>The dead rise at dawn...");
		}
		if($MMDay >= $MMDeadRising && $MMDeadRising > 0) {
			messageAll('',"<color:333333>The dead rise again...");
			%i = %mini.MMKillListNum;
			%mini.MMKillList[%i] = "<color:CC2222>The dead rise again...";
			%mini.MMKillListNum++;
			for(%i = 0; %i < ClientGroup.getCount(); %i++) {
				%client = ClientGroup.getObject(%i);
				MMRise(%client);
			}
		}
	}
}

// function deleteSun() {
	// for(%o=0;%o<missiongroup.getcount();%o++) {
		// %obj = missiongroup.getobject(%o);
		// if(isObject(%obj)) {
			// if(%obj.getclassname() $= "sun")
				// %obj.delete();
		// }
	// }
// }

function updateTime() {
	cancel($MMTimeLoop);
	//if(isObject($Sun)) {
	//	$Sun.delete();
	//}
	//deleteSun();
	if($MMTime%360 < 180) {
		%col = calculateDayColor((($MMTime*10)%1800)*0.1);
		MMTime(1);
	}
	else {
		%col = calculateNightColor((($MMTime*10)%1800)*0.1);
		MMTime(0);
	}
	%sun = nameToId("Sun");
	%sun.color = getWords(%col,0,2) SPC "1.0";
	%sun.ambient = getWords(%col,3,5) SPC "1.0";
	%sun.shadowcolor = getWords(%col,6,8) SPC "1.0";
	%sun.elevation = $MMTime%180;
	%sun.sendUpdate();
	// %Sun = new sun(Sun) {
		// color = getWords(%col,0,2) SPC "1.0"; //"0.6 0.6 0.6 1.0";
		// ambient = getWords(%col,3,5) SPC "1.0"; //"0.0 0.0 0.0 1.0";
		// azimuth = 238;
		// elevation = (($MMTime*10)%1800)*0.1;
	// };
	// if(isObject($Sun)) {
		// missiongroup.remove($Sun);
		// $Sun.delete();
	// }
	// $Sun = %Sun;
	// missionGroup.add($Sun);
	$MMTime+=1;
	if($MMisDay) {
		$MMTimeLoop = schedule(1050,0,updateTime);
	}
	else {
		$MMTimeLoop = schedule(700,0,updateTime);
	}
}

function calculateDayColor(%elev) {
	if(%elev == 90) {
		return "0.6 0.6 0.6 0.5 0.5 0.5" SPC "0.3 0.3 0.3";
	}
	else if (%elev > 90) {
		%elev -= 90;
		%elev = 90-%elev;
	}
	%elev = mPow(%elev / 90, 0.5);
	%r = 0.3 + (%elev * 0.3);
	%g = %elev * 0.6;
	%b = %elev * 0.6;
	%ra = 0.1 + (%elev * 0.4);
	%rb = %elev * 0.5;
	%rg = %elev * 0.5;
	return %r SPC %g SPC %b SPC %ra SPC %rb SPC %rg SPC "0.3 0.3 0.3";
	//0.3 0.0 0.0, 0.1 0.0 0.0
	//0.6 0.6 0.6, 0.5 0.5 0.5
	////1.0 0.3 0.0
	////0.7 0.7 1.0
}
function calculateNightColor(%elev) {
	if(%elev == 90) {
		return "0.075 0.075 0.1 0.01 0.01 0.05" SPC "0.05 0.05 0.05";
	}
	else if (%elev > 90) {
		%elev -= 90;
		%elev = 90-%elev;
	}
	%elev = mPow(%elev / 90, 0.0625);
	%r = 0.3 - (%elev * 0.225);
	%g = %elev * 0.075;
	%b = %elev * 0.1;
	%ra = 0.1 - (%elev * 0.09);
	%rb = %elev * 0.01;
	%rg = %elev * 0.05;
	return %r SPC %g SPC %b SPC %ra SPC %rb SPC %rg SPC "0.05 0.05 0.05";
	//0.075 0.075 0.1, 0.01 0.01 0.05
	//0.3 0.0 0.0, 0.1 0.0 0.0
}

function MMAbductCorpse(%hit,%cl,%obj,%name) {
	// %hit.setTransform($Pref::Server::MMDumpsterLoc SPC getWords(%hit.getTransform(),2,6));
	%hit.damage(%obj,%obj.getPosition(),100,$DamageType::Direct);
	if(isObject(%cl.corpse)) {
		%cl.corpse.fingerprints[0] = %name;
		%cl.corpse.fingerprintcount++;
	}
}

//Much of the avatar-related shit is copied or 'based off of' Space Guy's Team Deathmatch game-mode... so... sorry, I guess?
function GameConnection::applyMMSilhouette(%client) {
	applyMMSilhouette(%client.player);
}

function applyMMSilhouette(%player) {
	if(!isObject(%player)) {
		return;
	}
	if(%player.getName() $= "botCorpse") {
		%player.setNodeColor("ALL","1 0 0 1");
	}
	else {
		%player.setNodeColor("ALL","0.0 0.0 0.0 1.0");
	}
	if(%player.doombot) {
		%player.unHideNode("ALL");
		%player.setFaceName("smiley");
		%player.setDecalName("AAA-None");
		return;
	}
	if(fileName(%player.getDatablock().shapeFile) !$= "m.dts") {
		return;
	}
	%player.hideNode("ALL");
	
	if(isObject((%o = %player.getControlObject())) && %o.getDatablock().getName() $= "SkiVehicle") {
		%player.unHideNode("lski");
		%player.unHideNode("rski");
	}
	%player.unHideNode("headSkin");
	%player.unHideNode("chest");
	%player.unHideNode("pants");
	%player.unHideNode("LShoe");
	%player.unHideNode("RShoe");
	%player.unHideNode("LArm");
	%player.unHideNode("RArm");
	%player.unHideNode("LHand");
	%player.unHideNode("RHand");
	%player.setFaceName("smiley");
	%player.setDecalName("AAA-None");
}

function clearAllCorpses() {
	while(isObject(botCorpse)) {
		botCorpse.delete();
	}
}

function MMWinCheck(%client) {
	%mini = %client.minigame;
	// if(%client.isMaf) {
	if(%mini.resolved) {
		return;
	}
		for(%i = 0; %i < %mini.numMembers; %i++) {
			%cl = %mini.member[%i];
			if(%cl.lives > 0 && !%cl.player.dying) {
				if(%cl.isMaf) {
					%foundMaf = 1;
					if(%foundInno) {
						break;
					}
				}
				else {
					%foundInno = 1;
					if(%foundMaf) {
						break;
					}
				}
			}
			
		}
		if(!%foundMaf && %foundInno) {
			//serverCmdStopMM(%mini.member[0]);
			talk("The last Mafia is dead!  The Innocents have won.");
			%mini.resolved = 1;
			//schedule(3000,0,serverCmdStopMM,%mini.member[0]);
			%mini.schedule(3000,stopmm);
		}
		else if(%foundMaf && !%foundInno) {
			talk("The last Innocent is dead!  The Mafia have won.");
			%mini.resolved = 1;
			// schedule(3000,0,serverCmdStopMM,%mini.member[0]);
			%mini.schedule(3000,stopmm);
		}
		else if(!%foundMaf && !%foundInno) {
			talk("Everyone is dead.  The game has ended in a draw.");
			%mini.resolved = 1;
			// schedule(3000,0,serverCmdStopMM,%mini.member[0]);
			%mini.schedule(3000,stopmm);
		}
	// }
	// else {
		// for(%i = 0; %i < %mini.numMembers; %i++) {
			// %cl = %mini.member[%i];
			// if(!%cl.isMaf && %cl.lives > 0) {
				// %foundInno = 1;
				// break;
			// }
		// }
		// if(!%foundInno) {
			// serverCmdStopMM(%mini.member[0]);
			// talk("The last Innocent is dead!  The Mafia have won.");
			// schedule(3000,0,serverCmdStopMM,%mini.member[0]);
		// }
	// }
}

function serverCmdMafList(%client) {
	if($MMActive) {
		if(isObject(%mini = %client.minigame)) {
			if(%mini.MMGame) {
				if(%client.isMaf) {
					//for(%i=0;%i<%client.mafCount;%i++) {
					for(%i=0;%i<%mini.mafiacount;%i++) {
						//messageClient(%client,'', %client.mafName[%i]);
						messageClient(%client,'',%mini.mafia[%i]);
					}
				}
			}
		}
	}
}

function serverCmdBottomPrint(%client)
{
	MMBottomPrint(%client);
}

function MMBottomPrint(%client) {
	%client.bottomPrint("\c5You are:" SPC $MMRoleMsg[%client.role] SPC " " SPC "\c5ROLES\c6:" SPC %client.minigame.roles);
}

function PlayerToBot(%client) {
	%p = %client.player;
	if(!isObject(%p)) { return; }
	for(%i=0;%i<8;%i++) {
		%image[%i] = %p.getMountedImage(%i);
		%obj[%i] = %p.getMountedObject(%i);
	}
	%eyevec = %p.getEyeVector();
	%p.setName("tempPlayer");
	%b = new AIPlayer(tempBot:tempPlayer) { datablock = %p.getDatablock(); client = %client;};
	%b.setTransform(%p.getTransform());
	%b.setVelocity(%p.getVelocity());
	%b.setHealth(%p.getDatablock().maxDamage - %p.getDamageLevel());
	%p.delete();
	%b.setName("");
	%client.player = %b;
	%client.applyBodyParts();
	%client.applyBodyColors();
	for(%i=0;%i<8;%i++) {
		//%image[%i] = %p.getMountedImage(%i);
		//%obj[%i] = %p.getMountedObject(%i);
		if(%image[%i].armReady) {
			%b.playThread(1,armReadyRight);
		}
		%b.mountImage(%image[%i],%i);
		%b.mountObject(%obj[%i],%i);
	}
	%b.pitchAI = new AIConnection();
	%b.pitchAI.setControlObject(%b);
	//%b.pitchAI.setMove("pitch",-mAtan(getWord(%eyevec,2),getWord(%eyevec,1)));
	%b.pitchAI.setMove("pitch",-mAtan(getWord(%eyevec,2),VectorDist("0 0",getWord(%eyevec,0) SPC getWord(%eyevec,1))));
	%b.pitchAI.setControlObject(%b);
	%client.schedule(30,setControlObject,%b);
	%b.pitchAI.schedule(100,delete);
}

function BotToPlayer(%client) {
	%p = %client.player;
	if(!isObject(%p)) { return; }
	for(%i=0;%i<8;%i++) {
		%image[%i] = %p.getMountedImage(%i);
		%obj[%i] = %p.getMountedObject(%i);
	}
	%eyevec = %p.getEyeVector();
	%p.setName("tempPlayer");
	%b = new Player(tempBot:tempPlayer) { datablock = %p.getDatablock(); shapeName = %client.getSimpleName(); client = %client;};
	//talk(%b);
	//return;
	//%p.createPlayer();
	%b.setTransform(%p.getTransform());
	%b.setVelocity(%p.getVelocity());
	%b.setHealth(%p.getDatablock().maxDamage - %p.getDamageLevel());
	%p.delete();
	%b.setName("");
	%client.player = %b;
	%client.applyBodyParts();
	%client.applyBodyColors();
	for(%i=0;%i<8;%i++) {
		//%image[%i] = %p.getMountedImage(%i);
		//%obj[%i] = %p.getMountedObject(%i);
		if(%image[%i].armReady) {
			%b.playThread(1,armReadyRight);
		}
		%b.mountImage(%image[%i],%i);
		%b.mountObject(%obj[%i],%i);
	}
	%b.pitchAI = new AIConnection();
	%b.pitchAI.setControlObject(%b);
	//%b.pitchAI.setMove("pitch",-mAtan(getWord(%eyevec,2),getWord(%eyevec,1)));
	%b.pitchAI.setMove("pitch",-mAtan(getWord(%eyevec,2),VectorDist("0 0",getWord(%eyevec,0) SPC getWord(%eyevec,1))));
	%b.pitchAI.setControlObject(%b);
	%client.schedule(30,setControlObject,%b);
	%b.pitchAI.schedule(100,delete);
}

function serverCmdOldRules(%client) {
	messageClient(%client, '', "\c5Mafia Madness Rules:");
	messageClient(%client, '', "\c3THESE RULES ARE HEAVILY OUTDATED, STORED HERE JUST IN CASE.  TYPE /RULES TO READ THE NEW RULES.  YOU HAVE BEEN WARNED.");
	messageClient(%client, '', "\c5There are two teams, Mafia and Innocent.");
	messageClient(%client, '', "\c5At the start of the game, the Console will say an M for each mafioso, and an I for each innocent.");
	messageClient(%client, '', "\c5Other roles are the [C]razy (Mafia team) and the [F]ingerprint Expert (Innocent), discussed further down.");
	messageClient($client, '', "\c5You will receive a message after that telling you which you are.");
	messageClient(%client, '', "\c5Members of the mafia will also receive a list of all other members.  Read it carefully!");
	messageClient(%client, '', "\c5The Mafia must kill all Innocents, the Innocents must kill all Mafia.");
	messageClient(%client, '', "\c5Chat will only reach nearby people.  Start with a ! for a shout, use team chat for a low voice.");
	messageClient(%client, '', "\c5When a player dies, they leave a corpse.  Click the corpse to find out who they were.");
	messageClient(%client, '', "\c5Right clicking a corpse will pick it up.  Picking up a corpse will leave a Fingerprint on it.");
	messageClient(%client, '', "\c5When the Forensics Expert examines a corpse, they will receive a list of fingerprints.");
	messageClient(%client, '', "\c5There is only one Forensics Expert per game, so if two people are claiming to be him, one must be lying.");
	messageClient(%client, '', "\c5During night, it's hard to see who a player is unless they are very close.");
	messageClient(%client, '', "\c5The innocents usually meet at the roof or highest point of the map, so that is a good place to go at first.");
	messageClient(%client, '', "\c5If you're an innocent, you shouldn't kill someone unless you're pretty sure they're mafia.");
	messageClient(%client, '', "\c5If you're with the mafia, you shouldn't kill someone unless you're alone, OR you can kill all witnesses.");
	messageClient(%client, '', "\c5The innocents usually decide who to kill by voting, so be nice and don't kill people randomly to live.");
	messageClient(%client, '', "\c5Inbetween rounds, people will randomly kill each other because they will respawn.");
	messageClient(%client, '', "\c5The round starts when the minigame resets and you receive your role and \"It is now Dawn of the 1st Day.\"");
	messageClient(%client, '', "\c5There is also a special role called the \c0Crazy\c5 who has a knife, but is otherwise like any other Mafia.");
	messageClient(%client, '', "\c5The Crazy can use his knife on a corpse to make it unrecognizable if you examine it.");
	messageClient(%client, '', "\c5There will always be one crazy, who will show up as a C when the Console displays the role list.");
	messageClient(%client, '', "\c5Below are some of the things that you can do that BREAK the rules:");
	messageClient(%client, '', "\c51. Killing someone without even the slightest provocation or reason to believe they are mafia.  (If inno)");
	messageClient(%client, '', "\c52. Killing a fellow mafioso if you're mafia.  (One accidental breaking is OK if you forgot to check the list.)");
	messageClient(%client, '', "\c52a. EXCEPTION: Doing so can be part of a clever ploy to prove yourself innocent.");
	messageClient(%client, '', "\c53. Making a deliberate attempt to cause your team to lose.  (Incompetence is OK, but frowned on.)");
	messageClient(%client, '', "\c54. Showing screenshots of a game in progress to any other player of the game in progress.");
	messageClient(%client, '', "\c55. Using an external method of communicating to any other player of a game in progress about the game.");
	messageClient(%client, '', "\c5Breaking any of these rules may result in killing, kicking, banning, or canine murder.");
	messageClient(%client, '', "\c5You will usually be given a chance to explain yourself first, though.");
	messageClient(%client, '', "\c5But when the server is more full, I tend to be a bit trigger-happy in banning, so sorry in advance!");
	messageClient(%client, '', "\c5Use pgup and pgdown to navigate the rules.");
	messageClient(%client, '', "\c3THESE RULES ARE HEAVILY OUTDATED, STORED HERE JUST IN CASE.  TYPE /RULES TO READ THE NEW RULES.  YOU HAVE BEEN WARNED.");
}

function serverCmdRules(%client,%cat,%subcat) {
	%client.rules = 1;
	$MMReadRules[%client.bl_id] = 1;
	switch$(strLwr(%cat)) {
		case "1":
			// messageClient(%client,'',"\c4-MMRules- \c6\"/rules 1\" doesn't work!  Type \"/rules game basics\" instead.");
			serverCmdRules(%client,"game",%subcat);
		case "game":
			messageClient(%client,'',"\c4========Game Basics========");
			messageClient(%client,'',"\c4-MMRules- \c6In mafia madness, there are two teams: Mafia and Innocent!");
			messageClient(%client,'',"\c4-MMRules- \c6You win by killing everyone on the other team.");
			messageClient(%client,'',"\c4-MMRules- \c6The game is divided into \"rounds\" which are completely independent of each other.");
			messageClient(%client,'',"\c4-MMRules- \c6If someone's mafia in one round, that doesn't mean they're mafia in the next round.");
			messageClient(%client,'',"\c4-MMRules- \c6There is a short delay inbetween rounds, during which noone has a team and everyone respawns.");
			messageClient(%client,'',"\c4-MMRules- \c6This short delay is used by admins to find people who broke the rules in the last round.");
			messageClient(%client,'',"\c4-MMRules- \c6Inbetween the rounds, there's no rule against killing people.");
			messageClient(%client,'',"\c4-MMRules- \c6Once the round starts, however, the rules will be in full effect, so exercise caution!");
			// messageClient(%client,'',"\c4-MMRules- \c3You will be given a description of your role in the chat when you spawn.");
			messageClient(%client,'',"\c4-MMRules- \c3When you spawn, you will be given a chat message explaining briefly how to use your role.");
			// messageClient(%client,'',"\c4-MMRules- \c6When the game starts, the Mafia will be given a chat list of who all the other maf are.");
			messageClient(%client,'',"\c4-MMRules- \c6In addition, if you're Mafia you will also be given a list of who the other mafia are.");
			// messageClient(%client,'',"\c4-MMRules- \c6If you're Mafia, be sure to check the list carefully, as killing other maf may get you banned!");
			messageClient(%client,'',"\c4-MMRules- \c6You may have to page up to see it, so be sure to check it carefully.  See \c34\c6. Offenses for killing other Mafia.");
			// messageClient(%client,'',"\c4-MMRules- \c3You can type /maflist to see the list of mafia again, but only if you're mafia.");
			messageClient(%client,'',"\c4-MMRules- \c3If you miss it, you can type /maflist to check the list again.  (Mafia-only.)");
			messageClient(%client,'',"\c4-MMRules- \c6The Innocents don't know the role of anyone else when the game starts.");
			messageClient(%client,'',"\c4-MMRules- \c6To balance out the Mafia's foreknowledge, there's usually a lot more Innocents than Mafia in a game.");
			// messageClient(%client,'',"\c4-MMRules- \c6The mafia win by being sneaky and exploiting their knowledge to the greatest advantage!");
			messageClient(%client,'',"\c4-MMRules- \c6The Mafia win by infiltrating the Innos and getting them killed in ways that don't cause suspicion.");
			messageClient(%client,'',"\c4-MMRules- \c6The Innos win by using logic and reasoning to figure out who the mafia are.");
			messageClient(%client,'',"\c4========Game Basics========");
			messageClient(%client,'',"\c4-MMRules- \c6Use \c3PGUp\c6 and \c3PGDown\c6 to scroll the rules up and down.");
			%client.rules[1] = 1;
			$MMReadRules[%client.bl_id, 1] = 1;
		case "2":
			// messageClient(%client,'',"\c4-MMRules- \c6\"/rules 2\" doesn't work!  Type \"/rules advanced game rules\" instead.");
			serverCmdRules(%client,"advanced",%subcat);
		case "advanced":
			messageClient(%client,'',"\c4========Advanced Game Rules========");
			messageClient(%client,'',"\c4-MMRules- \c6When the game starts, it's dawn, signified by the reddish tinge of lighting.");
			messageClient(%client,'',"\c4-MMRules- \c6The sun will then slowly ascend through the sky, and eventually it will reach sunset.");
			messageClient(%client,'',"\c4-MMRules- \c6Once the sun sets, it will turn Night.");
			messageClient(%client,'',"\c4-MMRules- \c6During the night, everyone's avatars are blank!");
			messageClient(%client,'',"\c4-MMRules- \c6If you move close enough to a player, you can see their name.  (For now)");
			messageClient(%client,'',"\c4-MMRules- \c6Some Special Role abilities can only be used once per night.  (See the Special Roles section.)");
			// messageClient(%client,'',"\c4-MMRules- \c6Clicking someone will push them away, which you can use to kill someone if you push them from a high place.");
			// messageClient(%client,'',"\c4-MMRules- \c6Pushing someone should only be done if you are Mafia, as doing it as Innocent will probably get you shot.");
			messageClient(%client,'',"\c4-MMRules- \c6When a player dies, they'll leave a corpse.");
			messageClient(%client,'',"\c4-MMRules- \c6Clicking the corpse will tell you the name of the player, their role, and their Cause of Death.");
			messageClient(%client,'',"\c4-MMRules- \c6Right-click the corpse to pick it up, and right-click again to put it down.");
			messageClient(%client,'',"\c4-MMRules- \c6\"upstanding citizen\" on a corpse means they were inno, \"mafia scumbag\" means they were maf.");
			messageClient(%client,'',"\c4-MMRules- \c6See the Special Roles section for more corpse occupations.");
			messageClient(%client,'',"\c4-MMRules- \c6When you chat normally, only nearby players will hear the message!");
			messageClient(%client,'',"\c4-MMRules- \c6To shout so far-away people can hear, start your message with a !");
			messageClient(%client,'',"\c4-MMRules- \c6To speak in a low voice so people can't hear through walls, use Team Chat.  (Y by default)");
			messageClient(%client,'',"\c4-MMRules- \c6To speak in a whisper that only very close players can hear, use Team Chat and start with a !");
			messageClient(%client,'',"\c4-MMRules- \c6Dead players and spectators cannot be heard by any living player, but they can hear all chat!");
			messageClient(%client,'',"\c4-MMRules- \c6E.G. to shout \"everyone go to roof\" you would type \"!everyone go to roof\"!");
			messageClient(%client,'',"\c4-MMRules- \c6All Shouted messages come out in all-caps, regardless of how they were typed in.");
			messageClient(%client,'',"\c4========Advanced Game Rules========");
			messageClient(%client,'',"\c4-MMRules- \c6Use \c3PGUp\c6 and \c3PGDown\c6 to scroll the rules up and down.");
			%client.rules[2] = 1;
			$MMReadRules[%client.bl_id, 2] = 1;
		case "3":
			// messageClient(%client,'',"\c4-MMRules- \c6\"/rules 3\" doesn't work!  Type \"/rules special roles\" instead.");
			serverCmdRules(%client,"special",%subcat);
		case "special":
			switch$(strLwr(%subcat)) {
				case "abductor":
					messageClient(%client,'',"\c4-MMRules- ==" @ $MMRoleColor["A"] @ "Abductor\c4==");
					messageClient(%client,'',"\c4-MMRules- \c6The Abductor is a member of the Mafia who abducts Innocents.");
					messageClient(%client,'',"\c4-MMRules- \c6The Abductor's ability works by right-clicking an Innocent at close range.");
					messageClient(%client,'',"\c4-MMRules- \c6The Abductor's ability only works at night, and only works once per night.");
					messageClient(%client,'',"\c4-MMRules- \c6The body of the person abducted by the Abductor goes to the basement.");
					messageClient(%client,'',"\c4-MMRules- \c6The specific section it goes to is always opposite the spawn point in the basement.");
					messageClient(%client,'',"\c4-MMRules- \c6The Abductor shows up as" SPC $MMRoleColor["A"] @ "dark purple\c6 on the /maflist.");
					messageClient(%client,'',"\c4-MMRules- \c6The Abductor's ability does not work on mafia members.");
					messageClient(%client,'',"\c4-MMRules- \c6The Abductor's ability is hard to spot, but some players can spot it, so use it in crowds.");
					messageClient(%client,'',"\c4-MMRules- \c6The Abductor is \c3essential\c6 to the mafia for eliminating the Cop and Forensics Expert.");
					messageClient(%client,'',"\c4-MMRules- \c6Abducting someone leaves a fingerprint on the corpse.");
					messageClient(%client,'',"\c4-MMRules- \c6Therefor, it is essential that the Mafia prevent the Forensics Expert from seeing the bodies.");
					messageClient(%client,'',"\c4-MMRules- ==" @ $MMRoleColor["A"] @ "Abductor\c4==");
					messageClient(%client,'',"\c4-MMRules- \c6Use \c3PGUp\c6 and \c3PGDown\c6 to scroll the rules up and down.");
					%client.rules[3,"A"] = 1;
					$MMReadRules[%client.bl_id, 3, "A"] = 1;
				case "ventriloquist":
					messageClient(%client,'',"\c4-MMRules- ==\c7Ventriloquist\c4==");
					messageClient(%client,'',"\c4-MMRules- \c6The Ventriloquist is a member of the mafia who impersonates other players' voices.");
					messageClient(%client,'',"\c4-MMRules- \c6By typing /imp [name] (without the [ ]s), the Ventriloquist can disguise his voice.");
					messageClient(%client,'',"\c4-MMRules- \c6When the Ventriloquist's voice is disguised, any chat messages he send will appear to come from whoever he impersonated.");
					messageClient(%client,'',"\c4-MMRules- \c6Only the Ventriloquist or dead people can tell the difference between an impersonation and the real thing.");
					messageClient(%client,'',"\c4-MMRules- \c6The person the Ventriloquist impersonated will see the chat message too, but they may not notice it immediately.");
					messageClient(%client,'',"\c4-MMRules- \c6It is customary to shout \"VENTED\" if you are impersonated, see Terminology.");
					messageClient(%client,'',"\c4-MMRules- \c6In order to make the impersonation not visible to the target of the impersonation, the ventriloquist may use /impu instead.");
					// messageClient(%client,'',"\c4-MMRules- \c6/impu was recently added April 9th, though, so it may not work properly.  I encourage you to try it anyway.");
					messageClient(%client,'',"\c4-MMRules- \c6When using /impu, everyone but the person you impersonated will see the chat message.");
					messageClient(%client,'',"\c4-MMRules- \c6Typing either /impu or /imp with nothing after it will allow the Ventriloquist to return to normal chat.");
					messageClient(%client,'',"\c4-MMRules- \c6The Ventriloquist can use all forms of speaking while impersonating, including shouting, low voice, and whispering.");
					messageClient(%client,'',"\c4-MMRules- \c6However, the Ventriloquist's impersonation will only disguise their voice.  It will not change the location of the voice.");
					messageClient(%client,'',"\c4-MMRules- \c6E.G, if you whisper while impersonating someone, only people nearby YOU will hear it.");
					messageClient(%client,'',"\c4-MMRules- \c6Impersonating someone will not allow you to force them to use commands.  The commands will still come from you.");
					messageClient(%client,'',"\c4-MMRules- \c6The Ventriloquist is especially useful when he targets the Cop role, as then he can confuse the innocents and destroy the Cop's credibility.");
					messageClient(%client,'',"\c4-MMRules- \c6The Ventriloquist can also be used to manipulate voting, if done carefully.");
					messageClient(%client,'',"\c4-MMRules- ==\c7Ventriloquist\c4==");
					messageClient(%client,'',"\c4-MMRules- \c6Use \c3PGUp\c6 and \c3PGDown\c6 to scroll the rules up and down.");
					%client.rules[3,"V"] = 1;
					$MMReadRules[%client.bl_id, 3, "V"] = 1;
				case "godfather":
					messageClient(%client,'',"\c4-MMRules- ==\c6Godfather\c4==");
					messageClient(%client,'',"\c4-MMRules- \c6The Godfather is a member of the mafia who appears Innocent to the Cop!");
					messageClient(%client,'',"\c4-MMRules- \c6Whenever the Godfather is investigated by the Cop, the Cop will get the same result as if he had investigated an Innocent.");
					messageClient(%client,'',"\c4-MMRules- \c6However, the Paranoid Cop will still think the Godfather is suspicious, because the Paranoid Cop thinks everyone is suspicious.");
					messageClient(%client,'',"\c4-MMRules- \c6In addition, the Godfather has the ability to talk directly to the other mafia.");
					messageClient(%client,'',"\c4-MMRules- \c6By starting a message with ^, the Godfather can send messages that go directly to every mafia member without being intercepted.");
					messageClient(%client,'',"\c4-MMRules- \c6However, the other Mafia cannot respond to the Godfather in the same way, so the messages are one-way.");
					messageClient(%client,'',"\c4-MMRules- \c6The Godfather can use this ability to send plans and strategies to the other mafia.");
					messageClient(%client,'',"\c4-MMRules- \c6The Godfather can also use this to orchestrate a method of signaling that the mafia can use to send each other information.");
					messageClient(%client,'',"\c4-MMRules- ==\c6Godfather\c4==");
					messageClient(%client,'',"\c4-MMRules- \c6Use \c3PGUp\c6 and \c3PGDown\c6 to scroll the rules up and down.");
					%client.rules[3,"G"] = 1;
					$MMReadRules[%client.bl_id, 3, "G"] = 1;
				case "crazy":
					messageClient(%client,'',"\c4-MMRules- ==\c5Crazy\c4==");
					messageClient(%client,'',"\c4-MMRules- \c6The Crazy is a member of the mafia who can disfigure bodies!");
					messageClient(%client,'',"\c4-MMRules- \c6The Crazy spawns with a Knife, which, when used on a corpse, disfigures it.");
					messageClient(%client,'',"\c4-MMRules- \c6A disfigured body shows up with the name of \"disfigured corpse\" and the occupation of \"permanently retired\".");
					messageClient(%client,'',"\c4-MMRules- \c6You cannot learn the Cause of Death or take any Fingerprints from a disfigured corpse.");
					messageClient(%client,'',"\c4-MMRules- \c6The knife normally makes a small \"woosh\" sound, but you can also make it perfectly silent.");
					messageClient(%client,'',"\c4-MMRules- \c6To make the knife perfectly silent, hold down the mouse button for a short time before releasing.");
					messageClient(%client,'',"\c4-MMRules- \c6The knife will play a small animation to indicate that it's \"charging up\", and upon the conclusion, is perfectly silent.");
					messageClient(%client,'',"\c4-MMRules- \c6Whether the knife is silent or not, it will still disfigure corpses.");
					messageClient(%client,'',"\c4-MMRules- \c6While both silenced and non-silenced, the knife does enough damage to instantly kill a player.");
					messageClient(%client,'',"\c4-MMRules- \c6However, it can be somewhat inconvenient for that purpose compared to a gun.");
					messageClient(%client,'',"\c4-MMRules- \c6The Crazy's role in a game is often to lurk beneath the roof, killing any innocents he sees and disfiguring the bodies.");
					messageClient(%client,'',"\c4-MMRules- \c6The Crazy can also help the mafia by going to the Basement and disfiguring any bodies there.  (See Abductor role.)");
					messageClient(%client,'',"\c4-MMRules- \c6The Crazy will only appear in a game that already has 4 Mafia under the standard game-mode.");
					messageClient(%client,'',"\c4-MMRules- ==\c5Crazy\c4==");
					messageClient(%client,'',"\c4-MMRules- \c6Use \c3PGUp\c6 and \c3PGDown\c6 to scroll the rules up and down.");
					%client.rules[3,"C"] = 1;
					$MMReadRules[%client.bl_id, 3, "C"] = 1;
				case "cop":
					messageClient(%client,'',"\c4-MMRules- ==<color:1122CC>Cop\c4==");
					messageClient(%client,'',"\c4-MMRules- \c6sorry these aren't done yet, cop investigates with /inv");
					messageClient(%client,'',"\c4-MMRules- \c6also the initial for Cop is O, not C.  remember that.");
				default:
					messageClient(%client,'',"\c4========Special Roles========");
					messageClient(%client,'',"\c4-MMRules- \c6Some players will receive a role other than the basic \"Mafia\" and \"Innocent\"");
					messageClient(%client,'',"\c4-MMRules- \c6Having one of these roles is almost the same as being a basic Mafia or Innocent.");
					messageClient(%client,'',"\c4-MMRules- \c6The only difference is that you get an extra ability to use for your team.");
					messageClient(%client,'',"\c4-MMRules- \c6There will only be one of each of these roles per game, so if two people claim to have it, one's an imposter!");
					messageClient(%client,'',"\c4-MMRules- \c6One exception to the above rule is during a strange \"game mode\" such as \"I HATE YOU ALL\" or \"HAHAHAHAHAHAHA\".");
					messageClient(%client,'',"\c4-MMRules- \c6Another exception is the Cop role, where there will usually be a Paranoid Cop who thinks he's a Cop.");
					messageClient(%client,'',"\c4-MMRules- \c3A brief summary of each role will be given below.  To get a more extensive summary, type \c6/rules special [role name]");
					messageClient(%client,'',"\c4-MMRules- \c6In addition, even for roles lacking a summary, if you spawn as a role, you will receive a chat message detailing it.");
					messageClient(%client,'',"\c4-MMRules- \c6Here is the list of special roles:");
					messageClient(%client,'',"\c4-MMRules- ==" @ $MMRoleColor["A"] @ "Abductor\c4== \c3/rules special Abductor");
					messageClient(%client,'',"\c4-MMRules- \c6The Abductor is a mafia member who can abduct one person per night in perfect silence!");
					messageClient(%client,'',"\c4-MMRules- \c6When the Abductor abducts someone, they die instantly, and their body goes to the basement.");
					messageClient(%client,'',"\c4-MMRules- \c6Abducting someone leaves a fingerprint detectable by the Forensics Expert.");
					messageClient(%client,'',"\c4-MMRules- ==\c7Ventriloquist\c4== \c3/rules special Ventriloquist");
					messageClient(%client,'',"\c4-MMRules- \c6The Ventriloquist is a mafia member who can impersonate people's voices!");
					messageClient(%client,'',"\c4-MMRules- \c6The Ventriloquist can choose to make it so that the person they impersonate doesn't realize they were impersonated!");
					messageClient(%client,'',"\c4-MMRules- ==\c6Godfather\c4== \c3/rules special Godfather");
					messageClient(%client,'',"\c4-MMRules- \c6The Godfather is the mafia leader, who appears Innocent to the Cop!");
					messageClient(%client,'',"\c4-MMRules- \c6The Godfather can also talk directly to other mafia using ^");
					messageClient(%client,'',"\c4-MMRules- ==\c5Crazy\c4== \c3/rules special Crazy");
					messageClient(%client,'',"\c4-MMRules- \c6The Crazy is a mafia member who spawns with a knife which he can use to disfigure bodies!");
					messageClient(%client,'',"\c4-MMRules- \c6You can't get any information from a body which the Crazy has used his knife on!");
					messageClient(%client,'',"\c4-MMRules- ==" @ $MMRoleColor["F"] @ "Forensics Expert\c4==");
					messageClient(%client,'',"\c4-MMRules- \c6The Forensics Expert is an innocent who can check a body for fingerprints!");
					messageClient(%client,'',"\c4-MMRules- \c6The Forensics Expert will get a list of people who picked up a body, in order.");
					messageClient(%client,'',"\c4-MMRules- \c6The Forensics Expert can also see the relative time of death of the body.");
					messageClient(%client,'',"\c4-MMRules- ==<color:1122CC>Cop\c4==");
					messageClient(%client,'',"\c4-MMRules- \c6The Cop is an innocent who can investigate players and learn whether they're innocent or mafia using /inv [name]!");
					messageClient(%client,'',"\c4-MMRules- \c6The Cop can only investigate one person each night.  He is a very important role to the innocents!");
					messageClient(%client,'',"\c4-MMRules- ==" @ $MMRoleColor["P"] @ "Paranoid Cop\c4==");
					messageClient(%client,'',"\c4-MMRules- \c6The Paranoid Cop thinks he's a normal Cop, but will get \"suspicious\" every time he investigates anyone!");
					messageClient(%client,'',"\c4-MMRules- \c6Make sure you're not the Paranoid Cop before you kill someone for being suspicious, if you're a cop!");
					messageClient(%client,'',"\c4-MMRules- ==" @ $MMRoleColor["N"] @ "Naive Cop\c4==");
					messageClient(%client,'',"\c4-MMRules- \c6The Naive Cop is basically the same as the Paranoid Cop, but gets \"innocent\" instead when he investigates.");
					messageClient(%client,'',"\c4-MMRules- \c6The Naive Cop doesn't appear in standard games currently.  You can identify them in the roles list as \"N\".");
					messageClient(%client,'',"\c4-MMRules- ==" @ $MMRoleColor["L"] @ "Miller\c4==");
					messageClient(%client,'',"\c4-MMRules- \c6[]'s Notes: i added the miller recently as an experimental role, so he \c3might \c2appear in a game");
					messageClient(%client,'',"\c4-MMRules- \c6his initial is L and he's an inno who thinks he's a normal inno but cop and para think he's Guilty when they /inv him");
					messageClient(%client,'',"\c4-MMRules- ==" @ $MMRoleColor["D"] @ "Devil\c4==");
					messageClient(%client,'',"\c4-MMRules- \c6The Devil is a mafia role who can investigate Innocents like the cop.");
					messageClient(%client,'',"\c4-MMRules- \c6Instead of just learning whether a person is innocent or mafia, the Devil will learn their full role, such as Cop or Forensics Expert.");
					messageClient(%client,'',"\c4========Special Roles========");
					messageClient(%client,'',"\c4-MMRules- \c6Use \c3PGUp\c6 and \c3PGDown\c6 to scroll the rules up and down.");
					%client.rules[3] = 1;
					$MMReadRules[%client.bl_id, 3] = 1;
			}
		case "4":
			// messageClient(%client,'',"\c4-MMRules- \c6\"/rules 4\" doesn't work!  Type \"/rules offenses\" instead.");
			serverCmdRules(%client,"offenses",%subcat);
		case "offenses":
			if(strLwr(%subcat) $= "examples") {
				messageClient(%client,'',"\c4========Offense Examples========");
				messageClient(%client,'',"\c4-MMRules- \c6Here are some examples of breaking these rules (These aren't the only examples, though!)");
				messageClient(%client,'',"\c4-MMRules- 1. =Inno=\c6Seeing someone on the roof and shooting them instantly.");
				messageCLient(%client,'',"\c4-MMRules- \c6REASON: Just being on the roof alone is not a reason to believe someone is mafia!");
				messageClient(%client,'',"\c4-MMRules- 2. =Mafia=\c6Deciding to shoot everyone on the roof and shooting your fellow mafia members too.");
				messageClient(%client,'',"\c4-MMRules- \c6REASON: Your fellow mafia members are essential!  Shooting them does not help your team at all.");
				messageClient(%client,'',"\c4-MMRules- 3. =All=\c6As mafia, killing yourself when you spawn, or telling the Innocents who the mafia are.");
				messageClient(%client,'',"\c4-MMRules- \c6REASON: If you're mafia, you're mafia!  Selling your team out or refusing to play is childish and ruins the game.");
				messageClient(%client,'',"\c4-MMRules- 4. =All=\c6Using IRC to tell an alive player what happened either after or before you died.");
				messageClient(%client,'',"\c4-MMRules- \c6REASON: IRC is not part of the game, and using it or another out-of-game communication like this will get you banned permanently!");
				messageClient(%client,'',"\c4-MMRules- 5. =All=\c6Letting a friend use the same AUTH key as you and connect to the server.");
				messageClient(%client,'',"\c4-MMRules- \c6REASON: Two people with the same name is incredibly confusing in-game, as names are the only reliable method of identification.");
				messageClient(%client,'',"\c4-MMRules- \c6(extra: it'll also mess up the /inv and /imp commands)");
				messageClient(%client,'',"\c4-MMRules- 6. =Dead=\c6Spam-clicking the red ramp that spawns a new pong.");
				messageClient(%client,'',"\c4-MMRules- \c6REASON: It's a pain to reset the pong game once it's messed up, and spamming it may cause people lag.");
				messageClient(%client,'',"\c4========Offense Examples========");
				messageClient(%client,'',"\c4-MMRules- \c6Use \c3PGUp\c6 and \c3PGDown\c6 to scroll the rules up and down.");
				%client.rules[4,"E"] = 1;
				$MMReadRules[%client.bl_id, 4, "E"] = 1;
				return;
			}
			messageClient(%client,'',"\c4========Offenses========");
			messageClient(%client,'',"\c4-MMRules- \c6Here we will make a list of things which are \c3against \c6the rules, and could get you banned!");
			messageClient(%client,'',"\c4-MMRules- 1. =Inno=\c6DO NOT kill someone without even the slightest provocation or reason to believe they're mafia.");
			messageClient(%client,'',"\c4-MMRules- 2. =Mafia=\c6DO NOT kill any of your fellow Mafia members.");
			messageClient(%client,'',"\c4-MMRules- 2a.=Mafia=\c6EXCEPTION TO ABOVE: Doing so can be part of a clever ploy to prove yourself innocent.");
			messageClient(%client,'',"\c4-MMRules- 3. =All=\c6DO NOT make a deliberate attempt to cause your team to lose.");
			messageClient(%client,'',"\c4-MMRules- 4. =All=\c6DO NOT use any out-of-game method of communication to another player about a game in progress.");
			messageClient(%client,'',"\c4-MMRules- 5. =All=\c6DO NOT connect to the server with the same exact name as another player on the server.");
			messageClient(%client,'',"\c4-MMRules- 6. =Dead=\c6DO NOT deliberately attempt to mess up the Pong game in the Afterlife.");
			messageClient(%client,'',"\c4-MMRules- \c6Type \"/rules offenses examples\" to get some examples of breaking the rules, and reasons why.");
			messageClient(%client,'',"\c4========Offenses========");
			messageClient(%client,'',"\c4-MMRules- \c6Use \c3PGUp\c6 and \c3PGDown\c6 to scroll the rules up and down.");
			%client.rules[4] = 1;
			$MMReadRules[%client.bl_id, 4] = 1;
		case "5":
			// messageClient(%client,'',"\c4-MMRules- \c6\"/rules 5\" doesn't work!  Type \"/rules terminology\" instead.");
			serverCmdRules(%client,"terminology",%subcat);
		case "terminology":
			// messageClient(%client,'',"\c4-MMRules- \c6Sorry, this section of the rules is not finished yet.  Type \c0/oldrules\c6 for the old rules!");
			messageClient(%client,'',"\c4========Terminology========");
			messageClient(%client,'',"\c4-MMRules- \c6Here we'll make a small glossary of some terminology sometimes used in Mafia Madness.");
			messageClient(%client,'',"\c4-MMRules- \c6Maf: Short for a member of the Mafia.");
			messageClient(%client,'',"\c4-MMRules- \c6Scum: Same as Maf.");
			messageClient(%client,'',"\c4-MMRules- \c6Inno: Short for Innocent.");
			messageClient(%client,'',"\c4-MMRules- \c6Doc: Sometimes short for Forensics Expert.");
			messageClient(%client,'',"\c4-MMRules- \c6ROOF: means \"GO TO THE ROOF\".");
			messageClient(%client,'',"\c4-MMRules- \c6Basement: The series of tunnels at the base of the pyramid.");
			messageClient(%client,'',"\c4-MMRules- \c6Dumpster: A specific spot in the Basement where Abducted bodies are dumped.");
			messageClient(%client,'',"\c4-MMRules- \c6VENT: The Ventriloquist mafia role.  (See Special Roles.)");
			messageClient(%client,'',"\c4-MMRules- \c6VENTED: When someone is impersonated by the Ventriloquist.");
			messageClient(%client,'',"\c4-MMRules- \c6IMP/IMPED: short for Impersonate(d).  (See the Ventriloquist role.)");
			messageClient(%client,'',"\c4-MMRules- \c6Inv: Short for Investigate.  (See the Cop role.)");
			messageClient(%client,'',"\c4-MMRules- \c6PARA/PARANOID: means Paranoid Cop.");
			// messageClient(%client,'',"\c4-MMRules- \c6");
			messageClient(%client,'',"\c4========Terminology========");
			messageClient(%client,'',"\c4-MMRules- \c6Use \c3PGUp\c6 and \c3PGDown\c6 to scroll the rules up and down.");
			%client.rules[5] = 1;
			$MMReadRules[%client.bl_id, 5] = 1;
		case "6":
			// messageClient(%client,'',"\c4-MMRules- \c6\"/rules 6\" doesn't work!  Type \"/rules customs\" instead.");
			serverCmdRules(%client,"customs",%subcat);
		case "customs":
			// messageClient(%client,'',"\c4-MMRules- \c6Sorry, this section of the rules is not finished yet.  Type \c0/oldrules\c6 for the old rules!");
			messageClient(%client,'',"\c4========Customs========");
			messageClient(%client,'',"\c4-MMRules- \c6Customs are not hard rules, but usually they're what people will expect you to do.");
			messageClient(%client,'',"\c4========Roof and Voting========");
			messageClient(%client,'',"\c4-MMRules- \c6The first thing everyone does in a round is make their way to the Roof as fast as possible.");
			messageClient(%client,'',"\c4-MMRules- \c6If you can't find your way to the roof, just look around until you find an upwards stairway, and never go down.");
			messageClient(%client,'',"\c4-MMRules- \c6Once everyone is on the Roof, the typical strategy to find the mafia is to vote on who to kill.");
			messageClient(%client,'',"\c4-MMRules- \c6If you don't vote on who to kill, the Mafia and the Abductor will slowly eliminate you regardless.");
			messageClient(%client,'',"\c4-MMRules- \c6You should never, however, vote to kill the Cop, Paranoid Cop, or Forensics Expert.");
			messageClient(%client,'',"\c4-MMRules- \c6Typically, you should avoid killing someone directly until a majority vote has been reached.");
			messageClient(%client,'',"\c4-MMRules- \c6Leaving the roof is a bad idea, as then people will suspect you of being mafia, and sometimes shoot you.");
			messageClient(%client,'',"\c4-MMRules- \c6Unexpectedly shooting someone is a good way to get yourself killed.  If you announce it first, you're more likely to survive.");
			messageClient(%client,'',"\c4-MMRules- \c6The Mafia should attempt to infiltrate the roof subtly, and manipulate the voting.");
			messageClient(%client,'',"\c4========Mafia Duties========");
			messageClient(%client,'',"\c4-MMRules- \c6Each special member of the Mafia has their own duty to perform in the game.");
			messageClient(%client,'',"\c4-MMRules- \c6The Abductor's duty is to eliminate very dangerous roles like the Cop or Forensics Expert.");
			messageClient(%client,'',"\c4-MMRules- \c6The Ventriloquist's duty is to confuse the innocents about the Cop, manipulate the vote, and cause split-second kills.");
			messageClient(%client,'',"\c4-MMRules- \c6The Godfather's duty is to unite the mafia with a shared strategy.");
			messageClient(%client,'',"\c4-MMRules- \c6The Crazy's duty is to be a loose cannon, operating below-roof and silently disfiguring as many bodies as possible.");
			messageClient(%client,'',"\c4-MMRules- \c6The Crazy is also important for making sure that the Forensics Expert can't find out who the Abductor is.");
			messageClient(%client,'',"\c4========Dos and Don'ts========");
			messageClient(%client,'',"\c4-MMRules- \c6While on the roof, there are some things that if you do them, you might be shot instantly without voting.");
			messageClient(%client,'',"\c4-MMRules- \c6Shooting someone without declaring it first or any votes having passed will obviously likely get you shot.");
			messageClient(%client,'',"\c4-MMRules- \c6Jumping off the roof or leaving the roof suddenly will also probably get you shot.");
			messageClient(%client,'',"\c4-MMRules- \c6Throwing bodies off the roof, or taking bodies from the pile and carrying them will also get you shot.");
			messageClient(%client,'',"\c4-MMRules- \c6When you find a body, you should report its' name and role, and bring it to the roof.");
			messageClient(%client,'',"\c4-MMRules- \c6At night, while the Abductor is alive, don't run too close to someone, or people might get suspicious.");
			messageClient(%client,'',"\c4-MMRules- \c6Pulling out a gun for no reason or shooting at something for no reason will most likely get you shot.");
			// messageClient(%client,'',"\c4-MMRules- \c3Pushing /anyone/ has a good chance of getting you shot.  It's dangerous, and extremely suspicious.");
			messageClient(%client,'',"\c4-MMRules- \c6Finally, disguising yourself as a body (avatar entirely red, default blocko) is very suspicious and might get you shot.");
			messageClient(%client,'',"\c4-MMRules- \c6Also, people tend to vote people who wear pedobear avatars when there's no other reasons to vote.");
			messageClient(%client,'',"\c4========Customs========");
			messageClient(%client,'',"\c4-MMRules- \c6Use \c3PGUp\c6 and \c3PGDown\c6 to scroll the rules up and down.");
			%client.rules[6] = 1;
			$MMReadRules[%client.bl_id, 6] = 1;
		case "7":
			serverCmdRules(%client,"changelog",%subcat);
		case "changelog":
			messageClient(%client,'',"\c4-MMRules- \c3April 9th\c6:");
			messageClient(%client,'',"\c4-MMRules- \c6Added the Changelog.  Check here for updates!");
			messageClient(%client,'',"\c4-MMRules- \c6Added /impu to the Ventriloquist.");
			messageClient(%client,'',"\c4-MMRules- \c6Added Ventriloquist, Godfather, and Abductor subcategories to the Special Roles section.");
			messageClient(%client,'',"\c4-MMRules- \c6Made it so that zombies can now only whisper.");
			messageClient(%client,'',"\c4-MMRules- \c6Made it so that the dead rise at the dawn of the 4th day.");
			messageClient(%client,'',"\c4-MMRules- \c6Edited it so that the dead will re-rise every day/night after the dawn of the 4th.");
			messageClient(%client,'',"\c4-MMRules- \c3Added Clickpush.  Experimental!");
			messageClient(%client,'',"\c4-MMRules- \c3April 11th\c6:");
			messageClient(%client,'',"\c4-MMRules- \c6Fixed corpses seeing double of every chat they were in range for.");
			messageClient(%client,'',"\c4-MMRules- \c6Added mention of Clickpush to the Advanced Rules section, made a slight edit.");
			messageClient(%client,'',"\c4-MMRules- \c6Added Dos and Don'ts subsection to Customs.");
			messageClient(%client,'',"\c4-MMRules- \c6Added a detailed Crazy subcategory to the Special Roles section.  Type \c3/rules special crazy\c6 to see it!");
			messageClient(%client,'',"\c4-MMRules- \c3Removed clickpush.  Holy fuck.");
			messageClient(%client,'',"\c4-MMRules- \c3April 25th (or about then)\c6:");
			messageClient(%client,'',"\c4-MMRules- \c6Messed with the gun a lot!  Gun will now fire 6 shots, and then need manual reloading.");
			messageClient(%client,'',"\c4-MMRules- \c6Use the Light function, like with every other gun, to reload.");
			messageClient(%client,'',"\c4-MMRules- \c6You can reload an infinite number of times, and there is no way to tell how much ammo is in a gun.");
			messageClient(%client,'',"\c4-MMRules- \c6Added a rule against multiclienting in the Offenses section.  It's now official!  Mafia Madness hates multiclienters.");
			messageClient(%client,'',"\c4-MMRules- \c3April 26th (maybe???)\c6:");
			messageClient(%client,'',"\c4-MMRules- \c6Made gun slow you down while reloading, still buggy though and a bit crashy.");
			messageClient(%client,'',"\c4-MMRules- \c3Added a very rudimentary system wherein if you are shot you will stay alive for exactly one second.  Experimental!");
			messageClient(%client,'',"\c4-MMRules- \c3April 27th\c6:");
			messageClient(%client,'',"\c4-MMRules- \c6Removed all mention of Clickpush from the rules.  Hopefully.");
			messageClient(%client,'',"\c4-MMRules- \c6Fixed a bug that let you put away the gun while reloading to slow down more and more.");
			messageClient(%client,'',"\c4-MMRules- \c6Added a red flash to the Death and Dying system.");
			messageClient(%client,'',"\c4-MMRules- \c6Added message of \"IMP\" to the Terminology section.");
			messageClient(%client,'',"\c4-MMRules- \c6Fixed a bug that allowed dead bodies and dying people to shout and talk.");
			messageClient(%client,'',"\c4-MMRules- \c6Made you stand still for 3 seconds before dying when abducted.");
			messageClient(%client,'',"\c4-MMRules- \c3May 2nd(?)\c6:");
			messageClient(%client,'',"\c4-MMRules- \c6Abducting people now properly leaves fingerprints on the bodies.  (Bugfix)");
			messageClient(%client,'',"\c4-MMRules- \c3May 4th\c6:");
			messageClient(%client,'',"\c4-MMRules- \c6Mafia should now be able to tell when a chat message is from the Vent.");
			messageClient(%client,'',"\c4-MMRules- \c3May 8th\c6:");
			messageClient(%client,'',"\c4-MMRules- \c6Added the experimental role Miller and a short passage about him in the Specal Roles section.");
			messageClient(%client,'',"\c4-MMRules- \c6Added an experimental 'afterlife' to hang out in when you're dead.  Currently empty.");
			messageClient(%client,'',"\c4-MMRules- \c3May 18th\c6:");
			messageClient(%client,'',"\c4-MMRules- \c6Added a Pong machine in the Afterlife, and made it so you could toggle Afterlife/Spectate using the Light key.");
			messageClient(%client,'',"\c4-MMRules- \c6Updated the Offenses section to have a rule against fucking with the pong game.");
			messageClient(%client,'',"\c4-MMRules- \c6Made some minor edits to the Game Basics section to increase readability and clearness.");
			messageClient(%client,'',"\c4-MMRules- \c6Fixed the Crazy's Knife causing the same delayed death as a gunshot wound.");
			messageClient(%client,'',"\c4-MMRules- \c6Enlarged the range of picking up corpses and abducting people by 3/5ths.");
			messageClient(%client,'',"\c4-MMRules- \c6Added an experimental swordfighting arena in the Afterlife.");
			messageClient(%client,'',"\c4-MMRules- \c3June 1st\c6:");
			messageClient(%client,'',"\c4-MMRules- \c6Updated The Summoning to use Low chat instead of Say chat.");
			messageClient(%client,'',"\c4-MMRules- \c6The Summoning will now kill you if you say it 3 times, and only function if the stars are aligned to the milisecond.");
			messageClient(%client,'',"\c4-MMRules- \c3June 3rd\c6:");
			messageClient(%client,'',"\c4-MMRules- \c6Made it so that people who are Abducted can still move, and might not even realize they're abducted.");
			messageClient(%client,'',"\c4-MMRules- \c6Pressing the Light Key in the afterlife now works properly.  (No more pressing Space twice!)");
			messageClient(%client,'',"\c4-MMRules- \c3June 7th\c6:");
			messageClient(%client,'',"\c4-MMRules- \c6Added the Naive Cop.  (See Special Roles.)");
			messageClient(%client,'',"\c4-MMRules- \c6Added a gamemode in which all mafia can abduct!  This will not be the default.");
			messageClient(%client,'',"\c4-MMRules- \c6Added a Limbo to the afterlife!  You can fight with guns and stuff.");
			messageClient(%client,'',"\c4-MMRules- \c3June 12th\c6:");
			messageClient(%client,'',"\c4-MMRules- \c6Removed an old line and added a new line to the Ventriloquist subcategory of Special Roles.  (/rules 3 Ventriloquist)");
			messageClient(%client,'',"\c4-MMRules- \c3June 22nd\c6:");
			messageClient(%client,'',"\c4-MMRules- \c6Added a new Gamemode, tentatively called \"Abduct Titanium Tonight\"!  In this gamemode, all mafia use Godfather chat!");
			messageClient(%client,'',"\c4-MMRules- \c6The WIP role \"Insane Cop\" now appears in one gamemode.  He always gets a random result!");
			messageClient(%client,'',"\c4-MMRules- \c3July 2nd\c6:");
			messageClient(%client,'',"\c4-MMRules- \c6Players who can't use Godfather chat can no longer make messages starting with ^.  Nice try.");
			messageClient(%client,'',"\c4-MMRules- \c6Edited the way the Kill List works.  This may screw up a bit.");
			messageClient(%client,'',"\c4-MMRules- \c3July 4th\c6:");
			messageClient(%client,'',"\c4-MMRules- \c6FIREWOOOOOOOORKS");
			messageClient(%client,'',"\c4-MMRules- \c6Fixed a HILARIOUS bug where Innos could talk to the mafia in Abduct Titanium Tonight with ^, but couldn't hear the messages.");
			messageClient(%client,'',"\c4-MMRules- \c3July 26th\c6:");
			messageClient(%client,'',"\c4-MMRules- \c6Revamped the /maflist command to list the individual roles of the mafia members and use proper colors.");
			messageClient(%client,'',"\c4-MMRules- \c6Abductions should now show up on the kill list.");
			messageClient(%client,'',"\c4-MMRules- \c3July 27th\c6:");
			messageClient(%client,'',"\c4-MMRules- \c6Added the" SPC $MMRoleColor["D"] @ "Devil \c6role, to appear in specific gamemodes.");
			messageClient(%client,'',"\c4-MMRules- \c6He's kind of like a mafia cop, who learns what type of inno as well as just whether they're inno or maf.");
			messageClient(%client,'',"\c4-MMRules- \c3August 26th\c6:");
			messageClient(%client,'',"\c4-MMRules- \c6Updated Mafia Madness for the Shadows and Shaders update!  It is now in Alpha until further notice.");
			messageClient(%client,'',"\c4-MMRules- \c6Renovated the day/night system to work with the Shaders update's new Day Cycles.");
			messageClient(%client,'',"\c4-MMRules- \c6Instituted temporary daycycles for Day and Night.  The daycycle is a gradient between red and cyan, and the night one is the reverse.");
			messageClient(%client,'',"\c4-MMRules- \c6Made the game into a gamemode compatible with the Gamemode system, and the Default Minigame.");
			messageClient(%client,'',"\c4-MMRules- \c6Highlighted an important line in Special Roles and added an extra one for those who failed to read Game Basics.");
			messageClient(%client,'',"\c4-MMRules- \c6Added the command to get more information about a role to the beginning of every role section in Special Roles.");
			messageClient(%client,'',"\c4-MMRules- \c3November 5th\c6:");
			messageClient(%client,'',"\c4-MMRules- \c6Added a selection of 4 different guns!  They are currently just reskins of the default gun, but I'll change their stats later.");
			messageClient(%client,'',"\c4-MMRules- \c6To use them, type /setgun # where # is a number between 0 and 3, and it will set your gun to that next time you spawn in-game.");
			messageClient(%client,'',"\c4-MMRules- \c3November 30th\c6:");
			messageClient(%client,'',"\c4-MMRules- \c6Fixed some bugs in Just Try To Survive, including one which allowed all innocents to abduct along with the mafia.");
			messageClient(%client,'',"\c4-MMRules- \c6Added Day, Night, and Dead Rising notifications to the Kill List.");
			%client.rules[7] = 1;
			$MMReadRules[%client.bl_id, 7] = 1;
		case "8":
			serverCmdRules(%client,"guns",%subcat);
		case "guns":
			messageClient(%client,'',"\c4========Gun Handling========");
			messageClient(%client,'',"\c4-MMRules- \c6In the new update by Jack Noir this gamemode now features a revolver with complex gun mechanics.");
			messageClient(%client,'',"\c4-MMRules- \c6If you have played Receiver you may recognise the similarities with the game's revolver.");
			messageClient(%client,'',"\c4========Controls========");
			messageClient(%client,'',"\c4-MMRules- \c6This really depends on your configured \c2Building Keys\c6. I will explain the controls using the brick-moving terms, and then list controls for");
			messageClient(%client,'',"\c4-MMRules- \c6Numpad Users. Here are all the controls so far:");
			messageClient(%client,'',"\c4-MMRules- \c3BrickShiftForward [Numpad 8]\c6 - Open/close chamber. Alternatively, use \c3light\c6 key.");
			messageClient(%client,'',"\c4-MMRules- \c3BrickShiftBackward [Numpad 2]\c6 - Eject bullets. Alternatively, use \c3jet\c6 key.");
			messageClient(%client,'',"\c4-MMRules- \c3BrickShiftLeft [Numpad 4] / BrickShiftRight [Numpad 6]\c6 - Spin chamber. Can be held down.");
			messageClient(%client,'',"\c4-MMRules- \c3BrickShiftDown (shift down 3x plates) [Numpad 5]\c6 - Insert bullet. Can hold down. Alternatively, you can click. Can't hold down in this case.");
			messageClient(%client,'',"\c4-MMRules- \c3Brick Rotation Keys [Numpad 7/9]\c6 - Pull out a single, selected bullet.");
			messageClient(%client,'',"\c4========Guide========");
			messageClient(%client,'',"\c4-MMRules- \c6<color:222222>Black O's\c6 = empty, <color:FF6622>Orange O's\c6 = spent bullet, <color:FFFF00>Yellow O's\c6 = functional bullet");
			messageClient(%client,'',"\c4-MMRules- \c6Open chamber, eject spent bullets if chambered, insert good bullets, close chamber. Spin for badassery.");
			messageClient(%client,'',"\c4-MMRules- \c6Headshots are 3x damage, when body shots deal 40 damage. Keep that in mind.");
			messageClient(%client,'',"\c4========Gun Handling========");
			messageClient(%client,'',"\c4-MMRules- \c6Use \c3PGUp\c6 and \c3PGDown\c6 to scroll the rules up and down.");
		default:
			messageClient(%client,'',"\c4-MMRules- \c6Welcome to the updated Mafia Madness rules!");
			messageClient(%client,'',"\c4-MMRules- \c6The game is a WIP and these rules may not be complete.");
			// messageClient(%client,'',"\c4-MMRules- \c6To see the old list of rules, type \c2/OldRules\c6 in chat.");
			messageClient(%client,'',"\c4-MMRules- \c6The rules will be split into categories for different subjects.");
			messageClient(%client,'',"\c4-MMRules- \c6To access a category, type /rules [category name]");
			messageClient(%client,'',"\c4-MMRules- \c6E.G. to access Category 1. Game Basics, you would type \"/rules game basics\"");
			messageClient(%client,'',"\c4-MMRules- \c3It's very important that you read all categories, as each is required to play.");
			messageClient(%client,'',"\c4-MMRules- \c6Here are the categories:");
			messageClient(%client,'',"\c4-MMRules- \c31\c6. Game Basics");
			messageClient(%client,'',"\c4-MMRules- \c32\c6. Advanced Game Rules");
			messageClient(%client,'',"\c4-MMRules- \c33\c6. Special Roles");
			messageClient(%client,'',"\c4-MMRules- \c34\c6. Offenses");
			messageClient(%client,'',"\c4-MMRules- \c35\c6. Terminology");
			messageClient(%client,'',"\c4-MMRules- \c36\c6. Customs");
			messageClient(%client,'',"\c4-MMRules- \c37\c6. Changelog (Not necessarily required.)");
			messageClient(%client,'',"\c4-MMRules- \c38\c6. Gun Handling for Dummies (You better read this.)");
			messageClient(%client,'',"\c4-MMRules- \c6Use \c3PGUp\c6 and \c3PGDown\c6 to scroll the rules up and down.");
	}
	export("$MMReadRules*", "config/server/mmrulesprefs.cs");
}

function serverCmdImp(%client, %v, %v1, %v2, %v3, %v4) {
	if(!$MMActive || !%client.minigame || !%client.minigame.MMGame || %client.role !$= "V") {
		return;
	}
	%v = trim(%v SPC %v1 SPC %v2 SPC %v3 SPC %v4);
	%c = findclientbyname(%v);
	if(%v $= "" || %c == %client) {
		%client.MMImpersonate = -1;
		messageClient(%client,'',"\c4You are no longer impersonating anyone.");
		%client.MMunnoticable = 0;
		return;
	}
	if(!isObject(%c)) {
		%c = findClientByBL_ID($Pref::Server::MMNicknames[%v]);
		if(!isObject(%c)) {
			messageClient(%client,'',"\c4Could not locate client\c3" SPC %v @ "\c4.");
			return;
		}
	}
	// if(isObject(%c)) {
	if((%c.MMIgnore && %c.lives < 1) || %c.minigame != %client.minigame) {
		messageClient(%client,'',"\c4That client is not part of the game!");
		return;
	}
	%client.MMImpersonate = %c;
	messageClient(%client,'',"\c4You are now impersonating\c3" SPC %c.getSimpleName() @ "\c4!");
	%client.MMunnoticable = 0;
		// return;
	// }
	// else {
		// messageClient(%client,'',"\c4Could not locate client\c3" SPC %v @ "\c4.");
	// }
}

function serverCmdImpU(%client,%v,%v1,%v2,%v3,%v4) {
	if(!$MMActive || !%client.minigame || !%client.minigame.MMGame || %client.role !$= "V") {
		return;
	}
	%v = trim(%v SPC %v1 SPC %v2 SPC %v3 SPC %v4);
	%c = findclientbyname(%v);
	if(%v $= "" || %c == %client) {
		%client.MMImpersonate = -1;
		messageClient(%client,'',"\c4You are no longer impersonating anyone.");
		%client.MMunnoticable = 0;
		return;
	}
	if(!isObject(%c)) {
		%c = findClientByBL_ID($Pref::Server::MMNicknames[%v]);
		if(!isObject(%c)) {
			messageClient(%client,'',"\c4Could not locate client\c3" SPC %v @ "\c4.");
			return;
		}
	}
	// if(isObject(%c)) {
	if((%c.MMIgnore && %c.lives < 1) || %c.minigame != %client.minigame) {
		messageClient(%client,'',"\c4That client is not part of the game!");
		return;
	}
	%client.MMImpersonate = %c;
	messageClient(%client,'',"\c4You are now impersonating\c3" SPC %c.getSimpleName() SPC "\c4unnoticably!");
	%client.MMunnoticable = 1;
	// return;
	// }
	// else {
		// messageClient(%client,'',"\c4Could not locate client\c3" SPC %v @ "\c4.");
	// }
}

function serverCmdInv(%client, %v, %v1, %v2, %v3, %v4) {
	if(!$MMActive || !%client.minigame || !%client.minigame.MMGame || (%client.role !$= "O" && %client.role !$= "P" && %client.role !$= "N" && %client.role !$= "IC" && %client.role !$= "D")) {
		return;
	}
	if(%client.lives < 1) {
		messageClient(%client,'',"\c4You cannot investigate someone while dead!");
		return;
	}
	if($MMisDay) {
		messageClient(%client,'',"\c4You can only investigate someone at night!");
		return;
	}
	if(%client.MMpaypas[$MMDay]) {
		messageClient(%client,'',"\c4You have already investigated someone tonight!");
		return;
	}
	%v = trim(%v SPC %v1 SPC %v2 SPC %v3 SPC %v4);
	%c = findclientbyname(%v);
	if(%v $= "") {
		messageClient(%client,'',"\c4You did not pick anyone to investigate!");
		return;
	}
	if(!isObject(%c)) {
		%c = findClientByBL_ID($Pref::Server::MMNicknames[%v]);
		if(!isObject(%c)) {
			messageClient(%client,'',"\c4No client by the name of\c3" SPC %v SPC "\c4found.");
			return;
		}
	}
	if(%c.minigame != %client.minigame || %c.MMIgnore) {
		messageClient(%client,'',"\c4That client is not part of the current game!");
		return;
	}
	if(%c == %client) {
		messageClient(%client,'',"\c4You cannot investigate yourself!");
		return;
	}
	if(%c.isMaf && %client.role $= "D") {
		messageClient(%client,'',"\c3" @ %c.getSimpleName() SPC "\c4is a fellow mafia, why are you investigating them?  Type \c3/maflist\c4 to see mafia roles.");
		return;
	}
	%client.MMpaypas[$MMDay] = 1;
	%mini = %client.minigame;
	if(!%mini.MMKillListNum) {
		%mini.MMKillListNum = 0;
	}
	%i = %mini.MMKillListNum;
	%mini.MMKillList[%i] = $MMRoleColor[%client.role] @ %client.getSimpleName() SPC "\c6investigated" SPC $MMRoleColor[%c.role] @ %c.getSimpleName();
	%mini.MMKillListNum++;
	if(%client.role $= "IC") {
		%rand = getRandom(0, 1);
		if(%rand) {
			messageClient(%client,'',"\c3" @ %c.getSimpleName() SPC "\c4is a pretty \c0suspicious fellow\c4 indeed!");
		}
		else {
			messageClient(%client,'',"\c3" @ %c.getSimpleName() SPC "\c4is a perfectly \c2upstanding citizen\c4 who bears no cause for suspicion.");
		}
		return;
	}
	if(%client.role $= "D") {
		%r = $MMRoleName[%c.role];
		if(%r $= "") {
			%r = $MMRoleMsg[%c.role];
		}
		messageClient(%client,'',"\c3" @ %c.getSimpleName() SPC "\c4is the" SPC %r @ "\c4!");
		return;
	}
	if(((%c.isMaf && %c.role !$= "G") || %client.role $= "P" || %c.role $= "L") && %client.role !$= "N") {
		messageClient(%client,'',"\c3" @ %c.getSimpleName() SPC "\c4is a pretty \c0suspicious fellow\c4 indeed!");
	}
	else {
		messageClient(%client,'',"\c3" @ %c.getSimpleName() SPC "\c4is a perfectly \c2upstanding citizen\c4 who bears no cause for suspicion.");
	}
}

function serverCmdGetNickname(%client, %v, %v1, %v2, %v3, %v4) {
	%v = trim(%v SPC %v1 SPC %v2 SPC %v3 SPC %v4);
	%blid = $Pref::ServeR::MMNicknames[%v];
	if(%blid !$= "") {
		%cl = findClientByBL_ID(%blid);
		if(isObject(%cl)) {
			messageClient(%client,'',"\c3The nickname of\c6" SPC %v SPC "\c3belongs to\c6" SPC %cl.getSimpleName() SPC "\c3.");
		}
		else {
			messageClient(%client,'',"\c3The nickname of\c6" SPC %v SPC "\c3belongs to BLID\c6" SPC %blid SPC "\c3.");
		}
	}
	else {
		messageClient(%client,'',"\c3The nickname of\c6" SPC %v SPC "\c3could not be found.");
	}
}

function serverCmdClaim(%client,%claim) {
	messageClient(%client,'',"\c3no fuck you");
	// if((%col = $MMRoleColorDec[%claim]) !$= "") {
	// 	if((%client.MMClaimTimeout+10000) > getRealTime()) {
	// 		messageClient(%client,'',"\c3You have already shifted your claim too recently!  Wait ten seconds.");
	// 		return;
	// 	}
	// 	if(isObject(%client.player)) {
	// 		%client.MMClaimTimeout = getRealTime();
	// 		%client.player.setShapeNameColor(%col);
	// 	}
	// }
}

function setPlayerGun(%this, %gun) {
	%this.player.tool[0] = nameToId(RevolverItem);
	messageClient(%this,'MsgItemPickup','',0,nameToId(RevolverItem));
	// switch(%gun) {
	// 	case 0:
	// 		%this.player.tool[0] = nameToId(MMPythonItem);
	// 		messageClient(%this,'MsgItemPickup','',0,nameToId(MMPythonItem));
	// 	case 1:
	// 		%this.player.tool[0] = nameToId(MMTanakaItem);
	// 		messageClient(%this,'MsgItemPickup','',0,nameToId(MMTanakaItem));
	// 	case 2:
	// 		%this.player.tool[0] = nameToId(MMSnubnoseItem);
	// 		messageClient(%this,'MsgItemPickup','',0,nameToId(MMSnubnoseItem));
	// 	case 3:
	// 		%this.player.tool[0] = nameToId(MMResearchBFRItem);
	// 		messageClient(%this,'MsgItemPickup','',0,nameToId(MMResearchBFRItem));
	// 	default:
	// 		talk("fail");
	// 		return;
	// }
}

function serverCmdSetGun(%client,%gun) {
	// if(%gun $= "") { %gun = 0; }
	// if(%gun >= 0 && %gun < 4) {
	// 	messageClient(%client,'',"\c4Your gun has been set to\c3" SPC %gun @ "\c4, the\c3" SPC $MMGunName[%gun] @ "\c4!");
	// 	%client.gun = %gun;
	// }
	// else {
	// 	messageClient(%client,'',"\c4Your gun must be a number between 0 and 3.  Try again.");
	// }
}

function aholeCmdSayCheck(%client,%msg) {
	switch$(strUpr(%msg)) {
		case "EVERY CASE IS GONNA BE AIRTIGHT":
			aholeAirtight(%client);
		// case "I AM BECOME DEATH, DESTROYER OF WORLDS":
			// aholeDoombot(%client);
	}
}

function aholeCmdShoutCheck(%client,%msg) {
	switch$(strUpr(%msg)) {
		case "FOR FREEDOM WE RISE":
			aholeGravity(%client);
		case "FUS RO DAH":
			aholeShout(%client);
		case "I TRUSTED YOU TITA":
			aholeBetrayed(%client);
	}
}

function aholeCmdWhisperCheck(%client,%msg) {
	return;
}

function aholeCmdLowCheck(%client,%msg) {
	switch$(strUpr(%msg)) {
		case "I AM BECOME DEATH, DESTROYER OF WORLDS":
			aholeDoombot(%client);
	}
}

function aholeAirtight(%client) {
	if(isObject(%p = %client.player)) {
		if(%p.airtight)
			return;
		%p.playThread(0,look);
		messageAll('',"\c3" @ %client.getSimpleName() SPC "\c6is looking for clues!");
		%p.airtight = 1;
	}
}

function aholeGravity(%client) {
	if(isObject(%p = %client.player)) {
		if(%p.gravity)
			return;
		if(%client.BL_ID == 10104) {
			%p.setVelocity("0 0 20");
			%p.schedule(100,setVelocity,"0 0 -200");
			messageAll('',"\c3" @ %client.getSimpleName() SPC "\c6sucks!");
			%p.gravity = 1;
			return;
		}
		%p.gravity = 1;
		%p.playAudio(0,"MusicData_Gravity_Hurts");
		%a = new AudioEmitter() { position = %p.getPosition(); coneVector = "0 1 0"; maxDistance = 50; profile = "MusicData_Gravity_Hurts";};
		%a.schedule(7000,delete);
		%p.setVelocity("0 0 200");
		messageAll('',"\c3" @ %client.getSimpleName() SPC "\c6learned to fly!");
	}
}

function aholeShout(%client) {
	if(isObject(%p = %client.player)) {
		if(%mini = %client.minigame) {
			if(($MMLastShout+1200000) > getRealTime()) {
				return;
			}
			$MMLastShout = getRealTime();
			%len = 30;
			%rad = 10;
			for(%i = 0;%i<%mini.numMembers;%i++) {
				%cl = %mini.member[%i];
				if(!isObject(%cl))
					continue;
				if(%cl == %client)
					continue;
				if(!isObject(%cl.player))
					continue;
				//talk("found a player, name is" SPC %cl.getSimpleName());
				%bPos = %cl.player.getEyePoint();
				%aPos = %p.getEyePoint();
				%aVec = %p.getEyeVector();
				//dest, then start
				%bVec = VectorSub(%bPos, %aPos);
				%cDist = (getWord(%aVec,0) * getWord(%bVec,0)) + (getWord(%aVec,1) * getWord(%bVec,1)) + (getWord(%aVec,2) * getWord(%bVec,2));
				if(%cDist > %len) {
					//talk("further away than length of cone, lol");
					continue;
				}
				%cPos = VectorAdd(%aPos, VectorScale(%aVec,%cDist));
				%cRad = %rad * (%cDist / %len);
				%cbDist = VectorDist(%cPos, %bPos);
				//talk(%cbDist);
				//talk(%cRad);
				//talk(%cR
				if(%cbDist <= %cRad) {
					//talk(VectorScale(VectorNormalize(%bVec),50));
					%cl.player.addVelocity(VectorScale(VectorNormalize(VectorSub(%bPos, VectorAdd(%aPos,"0 0 -2"))),50));
				}
			}
		}
	}
}

function aholeBetrayed(%client) {
	%player = %client.player;
	%titaplayer = findclientbyname("tita").player;
	if(isObject(%titaplayer) && isObject(%player)) {
		%player.damage(%titaplayer,"0 0 0",100,$DamageType::Gun);
		if(isObject(%client.corpse)) {
			%client.corpse.fingerprints[0] = "The Titanium";
			%client.corpse.fingerprintcount++;
		}
		messageAll('',"\c3" @ %client.getSimpleName() SPC "\c6was betrayed!");
	}
}

function aholeDoombot(%client) {
	if(isObject(%p = %client.player)) {
		if(%mini = %client.minigame) {
			if(%mini.doombot || %p.doombot)
				return;
			%p.doombotTries++;
			%lastdigits = getSubStr(getRealTime(),strLen(getRealTime())-2,2);
			echo(%lastDigits);
			if(%lastDigits == 13) {
				%mini.doombot = 1;
				%p.doombot = 1;
				%client.applyBodyParts();
				%client.applyBodyColors();
				messageAll('',"\c8He lives.");
			}
			else {
				if(%p.doombotTries == 3) {
					%p.kill();
					messageAll('',"\c6He sleeps.");
				}
			}
			// %mini.doombot = 1;
			// %p.doombot = 1;
			// %client.applyBodyParts();
			// %client.applyBodyColors();
			// messageAll('',"\c8He lives.");
		}
	}
}

package MafiaMadness {
	//This is to enforce night silhouettes.
	function GameConnection::applyBodyParts(%client) {
		if((%client.getClassName() $= "GameConnection" || %client.getClassName() $= "AIConnection") && !$MMisDay && $MMActive) {
			return;
		}
		else {
			Parent::applyBodyParts(%client);
		}
	}
	
	function GameConnection::applyBodyColors(%client) {
		if((%client.getClassName() $= "GameConnection" || %client.getClassName() $= "AIConnection") && !$MMisDay && $MMActive) {
			if(isObject(%client.getControlObject())) {
				%client.applyMMSilhouette();
			}
		}
		else {
			Parent::applyBodyColors(%client);
		}
		%p = %client.player;
		if(!isObject(%p)) {
			return;
		}
		if(%p.getName() $= "botCorpse") {
			%client.applyMMSilhouette();
			%p.setNodeColor("ALL","1 0 0 1");
		}
		else if(%p.doombot) {
			%p.unHideNode("ALL");
			%p.setNodeColor("ALL","0 0 0 1");			
			%p.setFaceName("smiley");
			%p.setDecalName("AAA-None");
		}
	}
	//Bot corpses!  Now, if only I could make them not collide...
	function GameConnection::onDeath(%client, %sourceObject, %sourceClient, %damageType, %damageArea) {
		
		if(!%client.player.silentDeath)
			serverplay3d("scream" @ getRandom(1, 5), %client.player.getEyePoint());
		if(!isObject(%mini = %client.minigame)) {
			return Parent::onDeath(%client, %sourceObject, %sourceClient, %damageType, %damageArea);
		}
		if(!$MMActive || !%mini.MMGame) {
			return Parent::onDeath(%client, %sourceObject, %sourceClient, %damageType, %damageArea);
		}
		if(%client.player.isGhost) {
			return Parent::onDeath(%client, %sourceObject, %sourceClient, %damageType, %damageArea);
		}
		if(isObject(%client.player.heldCorpse)) {
			%client.player.heldCorpse.dismount();
			//%client.player.heldCorpse.playThread(0,"death1");
			%client.player.heldCorpse = 0;
		}
		if(%sourceClient == %client) {
			%suicide = 1;
		}
		else if(!isObject(%sourceClient)) {
			%suicide = 2;
		}
		if(%suicide == 2 && isObject(%client.player.lastPushed)) {
			if(getRealTime() - %client.player.lastPushedTime < 5000) {
				%sourceClient = %client.player.lastPushed;
			}
		}
		if(!%mini.MMKillListNum) {
			%mini.MMKillListNum = 0;
		}
		%i = %mini.MMKillListNum;
		//%mini.MMKillList[%i,1] = $MMRoleColor[%client.role] @ %client.getSimpleName();
		if(isObject(%sourceClient)) { 
			//%mini.MMKillList[%i,0] = $MMRoleColor[%sourceClient.role] @ %sourceClient.getSimpleName();
			if(%sourceClient == %client) {
				%mini.MMKillList[%i] = $MMRoleColor[%client.role] @ %client.getSimpleName() SPC "\c6committed suicide";
			}
			else {
				%mini.MMKillList[%i] = $MMRoleColor[%sourceClient.role] @ %sourceClient.getSimpleName() SPC "\c6killed" SPC $MMRoleColor[%client.role] @ %client.getSimpleName();
			}
		}
		else {
			//%mini.MMKillList[%i,0] = %mini.MMKillList[%i,1];
			%mini.MMKillList[%i] = $MMRoleColor[%client.role] @ %client.getSimpleName() SPC "\c6fell to their death";
		}
		%mini.MMKillListNum++;
		%client.MMSpecMode = 0;
		// if(%client.player.getName() $= "botCorpse") {
			// %client.player.playthread(0,death1);
			// %client.player.client = 0;
			// %client.player = 0;
			// %client.setcontrolobject(%client.camera);
			// return;
		// }
		if(%client.player.getName() $= "botCorpse") {
			%client.player.setName("oldBotCorpse");
			%corpse = new AIPlayer(botCorpse : oldBotCorpse);
			%corpse.client = 0;
			%notarealdeath = 1;
		}
		else {
			%corpse = new AIPlayer(botCorpse) {
				datablock = CorpsePlayer;
				originalClient = %client;
				name = %client.name;
				job = $MMCorpseJob[%client.role];
				fingerprintcount = 0;
				timeofdeath = getRealTime();
				suicide = %suicide;
			};
			%corpse.startDrippingBlood(20);
		}
		if(%client.player.doombot) {
			%corpse.unhideNode("ALL");
			%corpse.doombot = 1;
		}
		if(isObject(%img = %client.player.getMountedImage(0))) {
			%corpse.mountImage(%img,0);
		}
		%corpse.setTransform(%client.player.getTransform());
		%client.player.removeBody();
		%corpse.setNodeColor("ALL","1.0 0.0 0.0 1.0");
		%corpse.mountImage(BlankImage, 3);
		%corpse.setImageTrigger(3,1);
		%corpse.playThread(3,"death1");
		if(!%notarealdeath)
			%client.corpse = %corpse;
		else
			%corpse.originalClient.corpse = %corpse;
		%client.camera.setMode("Corpse",%corpse);
		%client.setControlObject(%client.camera);
		if(!%notarealdeath)
			%client.lives--;
		if(isObject(%sourceClient)) {
			%client.bottomPrint("\c5You were killed by:" SPC (%sourceClient.isMaf ? "\c0" : "\c2") @ %sourceClient.getSimpleName());
		}
		if(%client.lives > 0) {
			%client.schedule(3000,spawnPlayer);
		}
		else {
			%client.isGhost = 1;
			MMWinCheck(%client);
			%client.schedule(3000,spawnPlayer);
		}
	}
	//Inspecting bot corpses!  woo
	//stolen basically directly from bot events (and slightly restyled) lol
	function Player::activateStuff(%this) {
		%r = Parent::activateStuff(%this);
		%cl = %this.client;
		%start = %this.getEyePoint();
		%end = vectorAdd(%start, vectorScale(%this.getEyeVector(), 5));
		%ray = containerRayCast(%start, %end, $Typemasks::PlayerObjectType | $Typemasks::FXbrickObjectType | $Typemasks::TerrainObjectType | $Typemasks::InteriorObjectType | $TypeMasks::VehicleObjectType, %this);
		if(isObject(%hit = getWord(%ray, 0)))
		{
			if(%hit.getClassName() $= "AIPlayer" && %hit.getName() $= "botCorpse")
			{
				messageClient(%cl,'',"\c2Name:\c3" SPC %hit.name);
				messageClient(%cl,'',"\c2Job:\c3" SPC %hit.job);
				if(!%hit.disfigured) {
					if(%hit.suicide == 1) {
						messageClient(%cl,'',"\c2Cause of death:\c3 Suicide");
					}
					else if(%hit.suicide == 2) {
						messageClient(%cl,'',"\c2Cause of death:\c3 Falling");
					}
					else {
						messageClient(%cl,'',"\c2Cause of death:\c3 Murder");
					}
				}
				if(%cl.role $= "F") {
					if(%hit.disfigured) {
						messageClient(%cl,'',"\c2You cannot gather any information from the corpse.");
						return;
					}
					%rtod = mFloor((getRealTime() - %hit.timeofdeath) / 1000);
					%rtod = %rtod - (%rtod % 30);
					%rsec = %rtod % 60;
					%rmin = (%rtod - %rsec) / 60;
					%rsec2 = (%rtod+30) % 60;
					%rmin2 = ((%rtod+30) - %rsec2) / 60;
					messageClient(%cl,'',"\c2Died between\c3" SPC %rmin SPC "\c2min\c3" SPC %rsec SPC "\c2sec and\c3" SPC %rmin2 SPC "\c2min\c3" SPC %rsec2 SPC "\c2secs ago.");
					if(%hit.fingerprintcount < 0) {
						talk("shit fucked up");
						return;
					}
					messageClient(%cl,'',"\c2Fingerprints:");
					for(%i = 0;%i<%hit.fingerprintcount;%i++) {
						messageClient(%cl,'',"\c2" @ %i+1 @ ".\c3" SPC %hit.fingerprints[%i]);
					}
				}
			}
		}
		if($MMActive && %cl.minigame.MMGame && $MMClickPush) {
			%end = vectorAdd(%start,vectorScale(%this.getEyeVector(), 2));
			%ray = containerRayCast(%start, %end, $Typemasks::PlayerObjectType | $Typemasks::FXbrickObjectType | $Typemasks::TerrainObjectType | $Typemasks::InteriorObjectType | $TypeMasks::VehicleObjectType, %this);
			if(isObject(%hit = getWord(%ray, 0)) && (%hit.getClassName() $= "Player" || %hit.getClassName() $= "AIPlayer")) {
				if(isObject(%hit.getControllingClient())) {
					%hit.setVelocity(VectorAdd(VectorScale(getWords(%this.getEyeVector(),0,1) SPC "0", 10),"0 0 5"));
					%hit.lastPushed = %cl;
					%hit.lastPushedTime = getRealTime();
				}
			}
		}
		return %r;
	}
	//Minigame stuff!  tyvm TDM
	function MinigameSO::addMember(%this,%client) {
		%r = Parent::addMember(%this,%client);
		if(%this.MMGame) {
			if(isObject(%p = %client.player)) {
				%p.delete();
			}
			if($Pref::Server::MMAfterlifeLoc !$= "") {
				%client.schedule(33,spawnPlayer);
				%client.centerPrint("<color:604060>You are now in the afterlife.  Wait until the next round to respawn.");
				return;
			}
			%cam = %client.camera;
			%cam.setMode("Observer");
			%client.setControlObject(%cam);
			%client.centerPrint("<color:604060>You are now spectating.  Wait until the next round to respawn.");
		}
		%client.schedule(33,spawnPlayer);
		return %r;
	}
	
	function MinigameSO::removeMember(%this,%client) {
		if(%this.MMGame && %client.lives > 0 && isObject(%client.player)) {
			%client.player.kill();
		}
		return Parent::removeMember(%this,%client);
	}
	
	function GameConnection::spawnPlayer(%this) {
		if(%this.minigame.MMGame) {
			if(%this.lives < 1 || %this.MMIgnore) {
				if($Pref::Server::MMAfterlifeLoc !$= "") {
					// %r = Parent::spawnPlayer(%this);
					if(isObject(%this.player)) {
						%this.player.delete();
					}
					%this.createPlayer($Pref::Server::MMAfterlifeLoc SPC "0 0 0 0");
					if(isObject(%this.player)) {
						// %this.player.setTransform($Pref::Server::MMAfterlifeLoc SPC "0 0 0 0");
						%this.player.setShapeNameDistance(13.5);
						%this.player.tool[0] = 0;
						%this.player.weaponcount--;
						%this.player.isGhost = 1;
					}
					else {
						talk("what the FUCK.");
					}
					%this.applyBodyParts();
					%this.applyBodyColors();
					%this.centerprint("");
					// return %r;
					return;
				}
				if(!isObject(%this.getControlObject())) {
					%cam = %this.camera;
					%cam.setMode("Observer");
					%this.setControlObject(%cam);
				}
				return;
			}
			%r = Parent::spawnPlayer(%this);
			if(isObject(%this.player)) {
				%this.player.setShapeNameDistance(13.5);
				setPlayerGun(%this, %this.gun);
			}
			if(%this.role $= "C") {
				if(!isObject(%this.player)) {
					talk("Wait, what?");
					return %r;
				}
				if(%this.player.tool[1] == 0) {
					%this.player.weaponCount++;
				}
				%this.player.tool[1] = nameToId(SilentCombatKnifeItem);
				messageClient(%this,'MsgItemPickup','',1,nameToId(SilentCombatKnifeItem));
				if(%this.thelaw) {
					if(%this.player.tool[2] == 0) {
						%this.player.weaponCount++;
					}
					%this.player.tool[2] = nameToId(TAssaultRifleItem);
					messageClient(%this,'MsgItemPickup','',2,nameToId(TAssaultRifleItem));
				}
			}
			if(%this.role $= "F")
			{
				%this.player.tool[1] = nameToId(ScannerItem);
				messageClient(%this,'MsgItemPickup','',1,nameToId(ScannerItem));
			}
			return %r;
		}
		Parent::spawnPlayer(%this);
	}
	
	function serverCmdMessageSent(%client,%msg) {
		if($MMActive) {
			%msg = stripMLControlChars(%msg);
			%msg = trim(%msg);
			if(%msg $= "") {
				return;
			}
			if((%mini = %client.minigame).MMGame) {
				if(isObject(%p=%client.player) && !%p.isGhost) {
					if($MMNoTalky !$= "") {
						if($MMNoTalky + 3000 > getRealTime()) {
							return;
						}
					}
					if(%p.gagged) {
						return;
					}
					if(%p.getName() $= "botCorpse" || %p.dying) {
						serverCmdTeamMessageSent(%client,%msg);
						return;
					}
					if(%client.role $= "V" && %client.MMImpersonate != -1) {
						if(isObject(%client.MMImpersonate)) {
							%unnoticable = %client.MMunnoticable;
							%realClient = %client;
							%client = %client.MMImpersonate;
							%impersonate = 1;
						}
					}
					//test for ALL CAPS
					%mark = getSubStr(%msg,0,1);
					//if(%mark $= "^" && (%client.role $= "G" || %mini.allComm)) {
					if(%mark $= "^") {
						if(!%client.isMaf || (%client.role !$= "G" && !%mini.allComm)) {
							messageClient(%client,'',"\c5You cannot use Godfather Chat because you are not the Godfather!  (^ is Godfather chat.)");
							return;
						}
						%msg = getSubStr(%msg,1,strLen(%msg)-1);
						%message = "\c7[\c6Godfather\c7]" @ %client.clanPrefix @ "\c3" @ %client.getSimpleName() @ "\c7" @ %client.clanSuffix @ "\c6:" SPC %msg;
						echo(%message);
						for(%i = 0; %i < clientGroup.getCount(); %i++) {
							%cl = clientGroup.getObject(%i);
							if(isObject(%cl) && ((%cl.lives < 1 || !%cl.minigame.MMGame) || (%cl.isMaf && isObject(%cl.player))))
								messageClient(%cl,'',%message);
						}
						return;
					}
					else if(((strCmp(strUpr(%msg),%msg) == 0) && (strCmp(strLwr(%msg),%msg) != 0)) || %mark $= "!") {
					//if(%mark = (getSubStr(%msg,0,1)) $= "!") {
						if(%mark $= "!") {
							%msg = strUpr(getSubStr(%msg,1,strLen(%msg)-1));
						}
						if(%impersonate) {
							//aholeCmdShoutCheck(%realClient,%msg);
						}
						else {
							//aholeCmdShoutCheck(%client,%msg);
						}
						%radius = 64;
						%message = "\c4[\c6SHOUT\c4]\c7" @ %client.clanPrefix @ "\c3" @ %client.getSimpleName() @ "\c7" @ %client.clanSuffix @ "\c6:" SPC %msg;
					}
					else {
						if(%impersonate) {
							// aholeCmdSayCheck(%realClient,%msg);
						}
						else {
							// aholeCmdSayCheck(%client,%msg);
						}
						%radius = 32;
						%message = "\c7" @ %client.clanPrefix @ "\c3" @ %client.getSimpleName() @ "\c7" @ %client.clanSuffix @ "\c6:" SPC %msg;
					}
					echo(%message);
					initContainerRadiusSearch(%p.getEyePoint(), %radius, $TypeMasks::PlayerObjectType);
					%obj = containerSearchNext();
					%i = 0;
					while(isObject(%obj)) {
						if(isObject(%obj.getControllingClient()) && %obj.getControllingClient().minigame == %mini && %obj.getName() !$= "botCorpse") {
							%heardPlayers[%i] = %obj;
							%i++;
						}
						%obj = containerSearchNext();
					}
					for(%i = 0; isObject(%heardPlayers[%i]); %i++) {
						//if(%impersonate && %heardPlayers[%i].getControllingClient() == %realClient) {
						if(%impersonate) {
							if(%heardPlayers[%i].getControllingClient() == %realClient || %heardPlayers[%i].getControllingClient().isMaf) {
								if(%unnoticable) {
									messageClient(%heardPlayers[%i].getControllingClient(),'',"\c4[\c6UNNOTICABLE\c4][\c6VENT\c3:\c6" @ %realClient.getSimpleName() @ "\c4]" @ %message);
								}
								else {
									messageClient(%heardPlayers[%i].getControllingClient(),'',"\c4[\c6VENT\c3:\c6" @ %realClient.getSimpleName() @ "\c4]" @ %message);
								}
								continue;
							}
							else if(%heardPlayers[%i].getControllingClient() == %client && %unnoticable) {
								continue;
							}
						}
						//else {
							messageClient(%heardPlayers[%i].getControllingClient(), '', %message);
						//}
					}
					for(%i = 0; %i < clientGroup.getCount(); %i++) {
						%cl = clientGroup.getObject(%i);
						if(isObject(%cl) && (%cl.lives < 1 || !%cl.minigame.MMGame)) {
							if(%impersonate) {
								if(%unnoticable) {
									messageClient(%cl,'',"\c4[\c6UNNOTICABLE\c4][\c6VENT\c3:\c6" @ %realClient.getSimpleName() @ "\c4]" @ %message);
								}
								else {
									messageClient(%cl,'',"\c4[\c6VENT\c3:\c6" @ %realClient.getSimpleName() @ "\c4]" @ %message);
								}
							}
							else {
								messageClient(%cl,'',%message);
							}
						}
					}
					return;
				}
				else if(%client.lives > 0){
					messageClient(%client,'',"\c5You are dead!  Wait until you respawn to say something.");
					return;
				}
				else {
					%pre = %client.isGhost ? "DEAD" : "SPEC";
					%message = "\c7*\c6" @ %pre @ "\c7*" SPC %client.clanPrefix @ "\c3" @ %client.getSimpleName() @ "\c7" @ %client.clanSuffix @ "\c6:" SPC %msg;
					echo(%message);
					for(%i = 0; %i < clientGroup.getCount(); %i++) {
						%cl = clientGroup.getObject(%i);
						if(isObject(%cl) && (%cl.lives < 1 || !%cl.minigame.MMGame)) {
							messageClient(%cl,'',%message);
						}
					}
					return;
				}
			}
			else {
				%pre = "SPEC";
				%message = "\c7*\c6" @ %pre @ "\c7*" SPC %client.clanPrefix @ "\c3" @ %client.getSimpleName() @ "\c7" @ %client.clanSuffix @ "\c6:" SPC %msg;
				echo(%message);
				for(%i = 0; %i < clientGroup.getCount(); %i++) {
					%cl = clientGroup.getObject(%i);
					if(isObject(%cl) && (%cl.lives < 1 || !%cl.minigame.MMGame)) {
						messageClient(%cl,'',%message);
					}
				}
				return;
			}
		}
		return Parent::serverCmdMessageSent(%client,%msg);
	}
	
	function serverCmdTeamMessageSent(%client,%msg) {
		if($MMActive) {
			%msg = stripMLControlChars(%msg);
			if((%mini = %client.minigame).MMGame) {
				if(isObject(%p=%client.player) && !%p.isGhost) {
					if($MMNoTalky !$= "") {
						if($MMNoTalky + 3000 > getRealTime()) {
							return;
						}
					}
					if(%p.gagged) {
						return;
					}
					if(%client.role $= "V" && %client.MMImpersonate != -1) {
						if(isObject(%client.MMImpersonate)) {
							%unnoticable = %client.MMunnoticable;
							%realClient = %client;
							%client = %client.MMImpersonate;
							%impersonate = 1;
						}
					}
					%mark = getSubStr(%msg,0,1);
					if(%mark $= "^" && (%client.role $= "G" || %mini.allComm)) {
						if(%p.getName() $= "botCorpse" || %p.dying) {
							return;
						}
						%msg = getSubStr(%msg,1,strLen(%msg)-1);
						%message = "\c7[\c6Godfather\c7]" @ %client.clanPrefix @ "\c3" @ %client.getSimpleName() @ "\c7" @ %client.clanSuffix @ "\c6:" SPC %msg;
						for(%i = 0; %i < clientGroup.getCount(); %i++) {
							%cl = clientGroup.getObject(%i);
							if(isObject(%cl) && ((%cl.lives < 1 || !%cl.minigame.MMGame) || (%cl.isMaf && isObject(%cl.player))))
								messageClient(%cl,'',%message);
						}
						return;
					}
					else if(%mark $= "!" || %p.getName() $= "botCorpse") {
						if(%mark $= "!") {
							%msg = strLwr(getSubStr(%msg,1,strLen(%msg)-1));
						}
						if(%impersonate) {
							// aholeCmdWhisperCheck(%realClient,%msg);
						}
						else {
							// aholeCmdWhisperCheck(%client,%msg);
						}
						%radius = 1;
						%message = "\c4[\c6Whisper\c4]\c7" @ %client.clanPrefix @ "\c3" @ %client.getSimpleName() @ "\c7" @ %client.clanSuffix @ "\c6:" SPC %msg;
					}
					else {
						// if(%p.getName() $= "botCorpse") {
							// return;
						// }
						if(%impersonate) {
							// aholeCmdLowCheck(%realClient,%msg);
						}
						else {
							// aholeCmdLowCheck(%client,%msg);
						}
						%radius = 8;
						if(%p.isDying)
							%message = "\c7[\c4Dying\c7]";
						else
							%message = "\c7[\c4Low\c7]";
						%message = %message SPC %client.clanPrefix @ "\c3" @ %client.getSimpleName() @ "\c7" @ %client.clanSuffix @ "\c6:" SPC %msg;
					}
					initContainerRadiusSearch(%p.getEyePoint(),%radius,$TypeMasks::PlayerObjectType);
					%obj = containerSearchNext();
					%i = 0;
					while(isObject(%obj)) {
						if(isObject(%obj.getControllingClient()) && %obj.getControllingClient().minigame == %mini) {
							%heardPlayers[%i] = %obj;
							%i++;
						}
						%obj = containerSearchNext();
					}
					for(%i = 0; isObject(%heardPlayers[%i]); %i++) {
						%start = %p.getEyePoint();
						%end = %heardPlayers[%i].getEyePoint();
						%ray = containerRayCast(%start, %end, $Typemasks::FXbrickObjectType);
						if(!isObject(getWord(%ray,0))) {
							//if(%impersonate && %heardPlayers[%i].getControllingClient() == %realClient) {
							if(%impersonate) {
								if(%heardPlayers[%i].getControllingClient() == %realClient || %heardPlayers[%i].getControllingClient().isMaf) {
									if(%unnoticable) {
										messageClient(%heardPlayers[%i].getControllingClient(),'',"\c4[\c6UNNOTICABLE\c4][\c6VENT\c3:\c6" @ %realClient.getSimpleName() @ "\c4]" @ %message);
									}
									else {
										messageClient(%heardPlayers[%i].getControllingClient(),'',"\c4[\c6VENT\c3:\c6" @ %realClient.getSimpleName() @ "\c4]" @ %message);
									}
									continue;
								}
								else if(%heardPlayers[%i].getControllingClient() == %client && %unnoticable) {
									continue;
								}
							}
							//else {
								messageClient(%heardPlayers[%i].getControllingClient(), '', %message);
							//}
						}
					}
					for(%i = 0; %i < clientGroup.getCount(); %i++) {
						%cl = clientGroup.getObject(%i);
						if(isObject(%cl) && (%cl.lives < 1 || !%cl.minigame.MMGame)) {
							if(%impersonate) {
								if(%unnoticable) {
									messageClient(%cl,'',"\c4[\c6UNNOTICABLE\c4][\c6VENT\c3:\c6" @ %realClient.getSimpleName() @ "\c4]" @ %message);
								}
								else {
									messageClient(%cl,'',"\c4[\c6VENT\c3:\c6" @ %realClient.getSimpleName() @ "\c4]" @ %message);
								}
							}
							else {
								messageClient(%cl,'',%message);
							}
						}
					}
					return;
				}
				else if(%client.lives > 0){
					messageClient(%client,'',"\c5You are dead!  Wait until you respawn to say something.");
					return;
				}
				else {
					%pre = %client.isGhost ? "DEAD" : "SPEC";
					%message = "\c7*\c6" @ %pre @ "\c7*" SPC %client.clanPrefix @ "\c3" @ %client.getSimpleName() @ "\c7" @ %client.clanSuffix @ "\c6:" SPC %msg;
					for(%i = 0; %i < clientGroup.getCount(); %i++) {
						%cl = clientGroup.getObject(%i);
						if(isObject(%cl) && (%cl.lives < 1 || !%cl.minigame.MMGame)) {
							// if(%impersonate) {
								// messageClient(%cl,'',"\c4[\c6VENT\c3:\c6" @ %realClient.getSimpleName() @ "\c4]" @ %message);
							// }
							// else {
								messageClient(%cl,'',%message);
							// }
						}
					}
					return;
				}
			}
		}
		return Parent::serverCmdTeamMessageSent(%client,%msg);
	}
	function serverCmdStartTalking(%client) {
		if(%client.minigame.MMGame) {
			return;
		}
		return Parent::serverCmdStartTalking(%client);
	}
	function Observer::onTrigger(%this,%obj,%slot,%on) {
		if(!$MMActive) {
			return Parent::onTrigger(%this,%obj,%slot,%on);
		}
		if(!isObject(%client = %obj.getControllingClient())) {
			return Parent::onTrigger(%this,%obj,%slot,%on);
		}
		if(!isObject(%mini = %client.minigame)) {
			return Parent::onTrigger(%this,%obj,%slot,%on);
		}
		if(!%mini.MMGame) {
			return Parent::onTrigger(%this,%obj,%slot,%on);
		}
		if(%client.lives > 0) {
			return Parent::onTrigger(%this,%obj,%slot,%on);
		}
		if(isObject(%client.player) && !%client.player.isGhost) {
			return Parent::onTrigger(%this,%obj,%slot,%on);
		}
		if(%on) {
			if(%slot == 0) {
				%client.centerprint("");
				if(%client.MMSpecMode) {
					// %cl = %this.client;
					%cam = %client.getControlObject();
					%start = %cam.getEyePoint();
					%end = vectorAdd(%start, vectorScale(%cam.getEyeVector(), 5));
					%ray = containerRayCast(%start, %end, $Typemasks::PlayerObjectType | $Typemasks::FXbrickObjectType | $Typemasks::TerrainObjectType | $Typemasks::InteriorObjectType | $TypeMasks::VehicleObjectType, %cam);
					if(isObject(%hit = getWord(%ray, 0)))
					{
						if(%hit.getClassName() $= "AIPlayer" && %hit.getName() $= "botCorpse")
						{
							messageClient(%client,'',"\c2Name:\c3" SPC %hit.name);
							messageClient(%client,'',"\c2Job:\c3" SPC %hit.job);
							if(%hit.suicide == 1) {
								messageClient(%client,'',"\c2Cause of death:\c3 Suicide");
							}
							else if(%hit.suicide == 2) {
								messageClient(%client,'',"\c2Cause of death:\c3 Falling");
							}
							else {
								messageClient(%client,'',"\c2Cause of death:\c3 Murder");
							}
							if(%client.role $= "F") {
								if(%hit.disfigured) {
									messageClient(%client,'',"\c2You cannot gather any information from the corpse.");
									return;
								}
								%rtod = mFloor((getRealTime() - %hit.timeofdeath) / 1000);
								%rtod = %rtod - (%rtod % 30);
								%rsec = %rtod % 60;
								%rmin = (%rtod - %rsec) / 60;
								%rsec2 = (%rtod+30) % 60;
								%rmin2 = ((%rtod+30) - %rsec2) / 60;
								messageClient(%client,'',"\c2Died between\c3" SPC %rmin SPC "\c2min\c3" SPC %rsec SPC "\c2sec and\c3" SPC %rmin2 SPC "\c2min\c3" SPC %rsec2 SPC "\c2secs ago.");
								if(%hit.fingerprintcount < 0) {
									talk("shit fucked up");
									return;
								}
								messageClient(%client,'',"\c2Fingerprints:");
								for(%i = 0;%i<%hit.fingerprintcount;%i++) {
									messageClient(%client,'',"\c2" @ %i+1 @ ".\c3" SPC %hit.fingerprints[%i]);
								}
							}
						}
					}
					return;
				}
				%client.MMSpecIndex++;
				if(%client.MMSpecIndex >= %mini.numMembers || %client.MMSpecIndex < 0) {
					%client.MMSpecIndex = 0;
				}
				// talk(%client.MMSpecIndex);
				if(isObject(%pl = %mini.member[%client.MMSpecIndex].player) && !%pl.isGhost) {
					%obj.setMode("Corpse",%pl);
					%client.setControlObject(%obj);
					return;
				}
				// for(%i = %client.MMSpecIndex; %i<%mini.numMembers;%i++) {
					// %cl = %mini.member[%i];
					// if(isObject(%cl.player)) {
						// %obj.setMode("Corpse",%cl.player);
						// %client.setControlObject(%obj);
						// %client.MMSpecIndex = %i;
						// return;
					// }
				// }
				for(%i = %client.MMSpecIndex; %i<%mini.numMembers;%i++) {
					%cl = %mini.member[%i];
					if(isObject(%cl.player) && !%cl.player.isGhost) {
						%obj.setMode("Corpse",%cl.player);
						%client.setControlObject(%obj);
						%client.MMSpecIndex = %i;
						// talk(%client.MMSpecIndex);
						return;
					}
				}
				for(%i = 0; %i<%client.MMSpecIndex;%i++) {
					%cl = %mini.member[%i];
					if(isObject(%cl.player) && !%cl.player.isGhost) {
						%obj.setMode("Corpse",%cl.player);
						%client.setControlObject(%obj);
						%client.MMSpecIndex = %i;
						return;
					}
				}
			}
			if(%slot == 4) {
				if(%client.MMSpecMode) {
					return;
				}
				%client.MMSpecIndex--;
				if(%client.MMSpecIndex >= %mini.numMembers || %client.MMSpecIndex < 0) {
					%client.MMSpecIndex = %mini.numMembers-1;
				}
				if(isObject(%pl = %mini.member[%client.MMSpecIndex].player) && !%pl.isGhost) {
					%obj.setMode("Corpse",%pl);
					%client.setControlObject(%obj);
					return;
				}
				// for(%i = %client.MMSpecIndex; %i<%mini.numMembers;%i++) {
					// %cl = %mini.member[%i];
					// if(isObject(%cl.player)) {
						// %obj.setMode("Corpse",%cl.player);
						// %client.setControlObject(%obj);
						// %client.MMSpecIndex = %i;
						// return;
					// }
				// }
				for(%i = %client.MMSpecIndex; %i >= 0;%i--) {
					%cl = %mini.member[%i];
					if(isObject(%cl.player) && !%cl.player.isGhost) {
						%obj.setMode("Corpse",%cl.player);
						%client.setControlObject(%obj);
						%client.MMSpecIndex = %i;
						// talk(%client.MMSpecIndex);
						return;
					}
				}
				for(%i = %mini.numMembers-1; %i>%client.MMSpecIndex;%i--) {
					%cl = %mini.member[%i];
					if(isObject(%cl.player) && !%cl.player.isGhost) {
						%obj.setMode("Corpse",%cl.player);
						%client.setControlObject(%obj);
						%client.MMSpecIndex = %i;
						return;
					}
				}
			}
			if(%slot == 2) {
				%client.centerprint("");
				if(%client.MMSpecMode) {
					if(isObject(%pl = %mini.member[%client.MMSpecIndex].player) && !%pl.isGhost) {
						%obj.setMode("Corpse",%pl);
						%client.setControlObject(%obj);
					}
					else {
						%origindex = %client.MMSpecIndex;
						for(%i = %client.MMSpecIndex; %i<%mini.numMembers;%i++) {
							%cl = %mini.member[%i];
							if(isObject(%cl.player) && !%cl.player.isGhost) {
								%obj.setMode("Corpse",%cl.player);
								%client.setControlObject(%obj);
								%client.MMSpecIndex = %i;
								%success = 1;
								break;
							}
						}
						if(!%success) {
							for(%i = 0; %i<%origindex;%i++) {
								%cl = %mini.member[%i];
								if(isObject(%cl.player) && !%cl.player.isGhost) {
									%obj.setMode("Corpse",%cl.player);
									%client.setControlObject(%obj);
									%client.MMSpecIndex = %i;
									break;
								}
							}
						}
					}
					%client.MMSpecMode = 0;
				}
				else {
					%obj.setMode("Observer");
					%client.setControlObject(%obj);
					%client.MMSpecMode = 1;
				}
			}
		}
	}
	function Armor::onTrigger(%this,%obj,%slot,%on) {
		if(!isObject(%client = %obj.getControllingClient())) {
			return Parent::onTrigger(%this,%obj,%slot,%on);
		}
		if(!isObject(%mini = %client.minigame)) {
			return Parent::onTrigger(%this,%obj,%slot,%on);
		}
		if(%client.minigame.MMGame) {
			if(isObject(%client.player) && %client.player == %client.getControlObject()) {
				if(%slot == 4 && !%client.player.isGhost) {
					if(%on) {
						if(isObject(%obj.heldCorpse)) {
							%obj.mountObject(%obj.heldCorpse,8);
							%obj.heldCorpse.dismount();
							%obj.heldCorpse.addVelocity(VectorScale(%obj.getForwardVector(),5));
							//%obj.heldCorpse.playThread(0,"death1");
							%obj.heldCorpse = 0;
							return;
						}
						%start = %obj.getEyePoint();
						%end = vectorAdd(%start, vectorScale(%obj.getEyeVector(), 8));
						%ray = containerRayCast(%start, %end, $Typemasks::PlayerObjectType | $Typemasks::FXbrickObjectType | $Typemasks::TerrainObjectType | $Typemasks::InteriorObjectType | $TypeMasks::VehicleObjectType, %obj);
						if(isObject(%hit = getWord(%ray, 0)))
						{
							if(%hit.getClassName() $= "AIPlayer" && %hit.getName() $= "botCorpse")
							{
								%obj.mountObject(%hit,0);
								%obj.heldCorpse = %hit;
								if(%hit.fingerprints[%hit.fingerprintcount-1] !$= %client.getSimpleName()) {
									%hit.fingerprints[%hit.fingerprintcount] = %client.getSimpleName();
									%hit.fingerprintcount++;
								}
								return Parent::onTrigger(%this,%obj,%slot,%on);
							}
							else if(%hit.getClassName() $= "Player" && isObject(%cl=%hit.getControllingClient())) {
								if((%client.role $= "A" || (%mini.allabduct == 1 && %client.isMaf)) && !%cl.isMaf && !%hit.gagged) {
									if(!$MMisDay) {
										if(!%client.MMmoidas[$MMDay]) {
											// %cl.camera.setMode("Corpse",%hit);
											// %cl.setControlObject(%cl.camera);
											%hit.gagged = 1;
											%hit.schedule(3000, setTransform, %mini.pickBrickLoc("abductpoint"));
											schedule(4000,0,MMAbductCorpse,%hit,%cl,%obj,%client.getSimpleName());
											// %hit.setTransform($Pref::Server::MMDumpsterLoc SPC getWords(%hit.getTransform(),2,6));
											// %hit.damage(%obj,%obj.getPosition(),100,$DamageType::Direct);
											// if(isObject(%cl.corpse)) {
												// %cl.corpse.fingerprints[0] = %client.getSimpleName();
												// %cl.corpse.fingerprintcount++;
											// }
											%client.MMmoidas[$MMDay] = 1;
											messageClient(%client,'',"\c2Abducted\c3" SPC %cl.getSimpleName() @ "\c2.");
											if(!%mini.MMKillListNum) {
												%mini.MMKillListNum = 0;
											}
											%i = %mini.MMKillListNum;
											%mini.MMKillList[%i] = $MMRoleColor[%client.role] @ %client.getSimpleName() SPC "\c6abducted" SPC $MMRoleColor[%cl.role] @ %cl.getSimpleName();
											%mini.MMKillListNum++;
										}
									}
								}
								else if(%client.role $= "J") {
									if($MMisDay) {
										if(!%client.MMjails[$MMDay]) {
											%hit.setTransform($MMJailLoc SPC getWords(%hit.getTransform(),2,6));
											%client.MMjails[$MMDay] = 1;
										}
									}
								}
							}
						}
					}
				}
				else if(%slot == 3) {
					%obj.crouch = %on;
				}
				// else if(%slot == 3) {
					// %p = %client.player;
					// %im = %client.player.getMountedImage(0);
					// if(isObject(%im)) {
						// if(%p.getImageState(0) $= "ReloadMid" && %im.item.MMcanReload) {
							// talk("derpoutput");
							// %p.crouchSetting = %on;
							// return;
						// }
					// }
				// }
			}
		}
		return Parent::onTrigger(%this,%obj,%slot,%on);
	}
	
	//function CombatKnifeImage::onFire(%this, %obj, %slot) {
	function SilentCombatKnifeImage::onFire(%this,%obj,%slot) {
		if(!$MMActive) { return Parent::onFire(%this, %obj, %slot); }
		if(!isObject(%client = %obj.client)) { return Parent::onFire(%this, %obj, %slot); }
		if(!%client.minigame.MMGame) { return Parent::onFire(%this, %obj, %slot); }
		//%obj.playThread(2,shiftto);
		//%obj.playThread(3,spearthrow);
		//%obj.playThread(4,shiftdown);
		//%obj.playThread(5,shiftdown);
		//%obj.playThread(6,shiftdown);
		//%this.raycastExplosionBrickSound = 0;
		//%this.raycastExplosionPlayerSound = 0;
		//%this.raycastDirectDamage = 105;
		//WeaponImage::onFire(%this,%obj,%slot);
		Parent::onFire(%this,%obj,%slot);
		%start = %obj.getEyePoint();
		%end = vectorAdd(%start, vectorScale(%obj.getEyeVector(),%this.raycastWeaponRange));
		%ray = containerRayCast(%start, %end, %this.raycastWeaponTargets, %obj);
		if(isObject(%hit = getWord(%ray,0))) {
			if(%hit.getClassName() $= "AIPlayer" && %hit.getName() $= "botCorpse") {
				if(%hit.disfigured) {
					messageClient(%client,'',"\c4That corpse is already unrecognizable!");
					return;
				}
				messageClient(%client,'',"\c4You have made the corpse of\c3" SPC %hit.name SPC "\c4unrecognizable.");
				%hit.name = "disfigured corpse";
				%hit.job = "permanently retired";
				%hit.disfigured = 1;
			}
		}
	}
	function SilentCombatKnifeImage::onStabFire(%this,%obj,%slot) {
		if(!$MMActive) { return Parent::onStabFire(%this, %obj, %slot); }
		if(!isObject(%client = %obj.client)) { return Parent::onStabFire(%this, %obj, %slot); }
		if(!%client.minigame.MMGame) { return Parent::onStabFire(%this, %obj, %slot); }
		Parent::onStabFire(%this,%obj,%slot);
		%start = %obj.getEyePoint();
		%end = vectorAdd(%start, vectorScale(%obj.getEyeVector(),%this.raycastWeaponRange));
		%ray = containerRayCast(%start, %end, %this.raycastWeaponTargets, %obj);
		if(isObject(%hit = getWord(%ray,0))) {
			if(%hit.getClassName() $= "AIPlayer" && %hit.getName() $= "botCorpse") {
				if(%hit.disfigured) {
					messageClient(%client,'',"\c4That corpse is already unrecognizable!");
					return;
				}
				messageClient(%client,'',"\c4You have made the corpse of\c3" SPC %hit.name SPC "\c4unrecognizable.");
				%hit.name = "disfigured corpse";
				%hit.job = "permanently retired";
				%hit.disfigured = 1;
			}
		}
	}
	
	function serverCmdDropTool(%client,%slot) {
		// if($MMActive && %client.minigame.MMGame) {
		// 	return;
		// }
		return parent::serverCmdDropTool(%client,%slot);
	}
	//disabling TDM mod's annoying bottomprints while MM is active
	function MinigameSO::displayScoresList(%mini) {
		if(%mini.MMGame || $MMActive) {
			return;
		}
		return Parent::displayScoresList(%mini);
	}
	//god DAMN it badspot.  god damn it.
	function SimObject::onCameraEnterOrbit(%this,%orbit) {
		if($MMActive) {
			return;
		}
		return Parent::onCameraEnterOrbit(%this,%orbit);
	}
	function serverCmdUnUseTool(%client) {
		if(isObject(%client.player)) {
			if(%client.player.noChangeWep) {
				return;
			}
		}
		if(%client.player.reloading) {
			if(isObject(%client.player) && isObject(%data = %client.player.getDatablock()) && isObject(%data.normalVersion)) {
				%client.player.setDatablock(%data.normalVersion);
			}
			%client.player.reloading = 0;
		}
		Parent::serverCmdUnUseTool(%client);
	}
	function serverCmdUseTool(%client,%a,%b,%c) {
		if(isObject(%client.player)) {
			if(%client.player.noChangeWep) {
				return;
			}
		}
		if(%client.player.reloading) {
			if(isObject(%client.player) && isObject(%data = %client.player.getDatablock()) && isObject(%data.normalVersion)) {
				%client.player.setDatablock(%data.normalVersion);
			}
			%client.player.reloading = 0;
		}
		Parent::serverCmdUseTool(%client,%a,%b,%c);
	}
	function GameConnection::AutoAdminCheck(%client) {
		%r = Parent::AutoAdminCheck(%client);
		if(strLen($Pref::Server::MOTD) > 0) {
			messageClient(%client,'',$Pref::Server::MOTD);
		}
		if(strLen($Pref::Server::MOTD2) > 0) {
			messageClient(%client,'',$Pref::Server::MOTD2);
		}
		if(strLen($Pref::Server::MOTD3) > 0) {
			messageClient(%client,'',$Pref::Server::MOTD3);
		}
		if(strLen($Pref::Server::MOTD4) > 0) {
			messageClient(%client,'',$Pref::Server::MOTD4);
		}
		
		serverCmdSetGun(%client,getRandom(0,3));
		
		return %r;
	}
	function servercmdsit(%client) {
		if(isObject(%client.player)) {
			if(%client.player.getName() $= "botCorpse") {
				%client.player.playthread(3,death1);
				return;
			}
		}
		return Parent::serverCmdSit(%client);
	}
	//"What are we copying today, []?"
	//"Why, this time we're copying Support_AmmoGuns.cs!"
	//"What a jolly good idea!"
	//"I'll say!"
	//most of it is rather direct copying, with some modifications to suit my needs
	function servercmdLight(%client)
	{
		if(isObject(%client.player) && isObject(%client.player.getMountedImage(0)) && %client.player.getName() !$= "BotCorpse")
		{
			%image = %client.player.getMountedImage(0);
			if(%image == nameToID(revolverImage) || %image.allowLightKey)
			{
				parent::servercmdLight(%client);
				return;
			}
		}
		//obviously the part right below this isn't from support_ammoguns but from player::pickup below for awhile it probably is
		if($MMActive && (%mini=%client.minigame).MMGame) {
			if(isObject(%client.player)) {
				if(%client.player.isGhost) {
					if(%client.getControlObject() != %client.player) {
						%client.setControlObject(%client.player);
						return;
					}
					%cam = %client.camera;
					%cam.setMode("Observer");
					%client.setControlObject(%cam);
					if(!%client.MMSpecMode) {
						if(%client.MMSpecIndex >= %mini.numMembers || %client.MMSpecIndex < 0 || %client.MMSpecIndex $= "") {
							%client.MMSpecIndex = 0;
						}
						if(isObject(%pl = %mini.member[%client.MMSpecIndex].player) && !%pl.isGhost) {
							%cam.setMode("Corpse",%pl);
							%client.setControlObject(%cam);
							return;
						}
						for(%i = %client.MMSpecIndex; %i<%mini.numMembers;%i++) {
							%cl = %mini.member[%i];
							if(isObject(%cl.player) && !%cl.player.isGhost) {
								%cam.setMode("Corpse",%cl.player);
								%client.setControlObject(%cam);
								%client.MMSpecIndex = %i;
								// talk(%client.MMSpecIndex);
								return;
							}
						}
						for(%i = 0; %i<%client.MMSpecIndex;%i++) {
							%cl = %mini.member[%i];
							if(isObject(%cl.player) && !%cl.player.isGhost) {
								%cam.setMode("Corpse",%cl.player);
								%client.setControlObject(%cam);
								%client.MMSpecIndex = %i;
								return;
							}
						}
					}
				}
				return;
			}
			else if(%client.lives < 1 && $Pref::Server::MMAfterlifeLoc !$= "") {
				%client.spawnPlayer();
			}
		}
		Parent::servercmdLight(%client);
	}
	//to be honest i'd like to use Support_AmmoGuns for this but their serverCmdDropTool is messing up my serverCmdDropTool, so sorry and thanks
	function Player::pickup(%this,%item)
	{
		%data = %item.dataBlock;
		%ammo = %item.weaponAmmoLoaded;
		%val = Parent::pickup(%this,%item);
		if(%val == 1 && %data.MMmaxAmmo > 0 && isObject(%this.client))
		{
			%slot = -1;
			for(%i=0;%i<%this.dataBlock.maxTools;%i++)
			{
				if(isObject(%this.tool[%i]) && %this.tool[%i].getID() == %data.getID() && %this.toolAmmo[%i] $= "")
				{
					%slot = %i;
					break;
				}
			}
			
			if(%slot == -1)
				return %val;
			
			if(%ammo $= "")
			{
				%this.toolAmmo[%slot] = %data.MMmaxAmmo;
			}
			else
			{
				%this.toolAmmo[%slot] = %ammo;
			}
		}
		return %val;
	}
	
	//This part is just going to be the same as Support_AmmoGuns, so I'm leaving it commented out for now.
	// function ItemData::onAdd(%this,%obj)
	// {
		// if($weaponAmmoLoaded !$= "")
		// {
			// %obj.weaponAmmoLoaded = $weaponAmmoLoaded;
			// $weaponAmmoLoaded = "";
		// }
		// Parent::onAdd(%this,%obj);
	// }
	
	function WeaponImage::onMount(%this,%obj,%slot)
	{	
		Parent::onMount(%this,%obj,%slot);
		
		//If using one of the "force mount item" events, set the ammo to maximum
		if(%this.item.MMmaxAmmo >= 0 && (%obj.currTool == -1 || %obj.toolAmmo[%obj.currTool] $= ""))
		{
			%obj.toolAmmo[%obj.currTool] = %this.item.MMmaxAmmo;
		}
	}
	//just had to replace the MMmaxAmmo here
	function WeaponImage::onMMLoadCheck(%this,%obj,%slot)
	{
		if(%obj.toolAmmo[%obj.currTool] <= 0 && %this.item.MMmaxAmmo > 0 && %obj.getState() !$= "Dead")
			%obj.setImageAmmo(%slot,0);
		else
			%obj.setImageAmmo(%slot,1);
	}
	//aaaand we should be done with that now
	function Player::damage(%this, %obj, %pos, %amt, %type) {
		%techAmt = %this.Crouch ? %amt * 2.1 : %amt;
		if(%this.getName() $= "botCorpse") { return; }
		if(%this.isGhost) {
			if($Pref::Server::MMArenaLoc !$= "") {
				%ringX = getWord($Pref::Server::MMArenaLoc,0)-6;
				%ringX2 = %ringX+12;
				%ringY = getWord($Pref::Server::MMArenaLoc,1)-6;
				%ringY2 = %ringY+12;
				%thisX = getWord(%this.getPosition(),0);
				%thisY = getWord(%this.getPosition(),1);
				// %objX = getWord(%obj.getPosition(),0);
				// %objY = getWord(%obj.getPosition(),1);
				// echo(%ringX SPC %ringX2 SPC %ringY SPC %ringY2 SPC %thisX SPC %thisY);
				// if(%thisX >= %ringX && %thisX <= %ringX2 && %thisY >= %ringY && %thisY <= %ringY2 && %objX >= %ringX && %objX <= %ringX2 && %objY >=/ %ringY && %objY <= %ringY2) {
				if(%thisX >= %ringX && %thisX <= %ringX2 && %thisY >= %ringY && %thisY <= %ringY2) {
					if(%this.getDatablock().maxDamage - %this.getDamageLevel() <= %techAmt) {
						if(isObject(%c = %this.client)) {
							%this.delete();
							%c.spawnPlayer();
							// talk("herp");
							return;
						}
						talk("wat");
					}
					$wat = 1;
					$wat2 = %this.getDamageLevel() SPC %this.getDatablock().maxDamage SPC %amt SPC %techAmt;
					schedule(33,0,resetwat);
					return Parent::damage(%this,%obj,%pos,%amt,%type);
				}
			}
			if($Pref::Server::MMLimboLoc !$= "") {
				%ringX = getWord($Pref::Server::MMLimboLoc,0);
				%ringX2 = %ringX+128;
				%ringY = getWord($Pref::Server::MMLimboLoc,1);
				%ringY2 = %ringY+128;
				%thisX = getWord(%this.getPosition(),0);
				%thisY = getWord(%this.getPosition(),1);
				// %objX = getWord(%obj.getPosition(),0);
				// %objY = getWord(%obj.getPosition(),1);
				// echo(%ringX SPC %ringX2 SPC %ringY SPC %ringY2 SPC %thisX SPC %thisY);
				// if(%thisX >= %ringX && %thisX <= %ringX2 && %thisY >= %ringY && %thisY <= %ringY2 && %objX >= %ringX && %objX <= %ringX2 && %objY >=/ %ringY && %objY <= %ringY2) {
				if(%thisX >= %ringX && %thisX <= %ringX2 && %thisY >= %ringY && %thisY <= %ringY2) {
					talk("lul");
					echo("lul");
					if(%this.getDatablock().maxDamage - %this.getDamageLevel() <= %techAmt) {
						if(isObject(%c = %this.client)) {
							//%this.delete();
							if(isObject(%c.player)) {
								talk("waaaaaaaaaat.");
								echo("herp");
								%c.player.delete();
							}
							//%c.spawnPlayer();
							// talk("herp");
							echo("herp");
							return;
						}
						talk("wat");
						echo("wat");
					}
					talk("hur");
					echo("hur");
					return Parent::damage(%this,%obj,%pos,%amt,%type);
				}
			}
			return;
		}
		if(isObject(%client = %this.client))
		{
			if(%this.getDatablock().maxDamage - %this.getDamageLevel() <= %techAmt)
			{
				if(!isObject(%mini = %client.minigame)) {
					return Parent::damage(%this, %obj, %pos, %amt, %type);
				}
				if(!$MMActive || !%mini.MMGame) {
					return Parent::damage(%this, %obj, %pos, %amt, %type);
				}
				if(%this.dying || %this.getName() $= "botCorpse") {
					return Parent::damage(%this, %obj, %pos, %amt, %type);
				}
				//echo(%type SPC %client.getSimpleName());
				if(%type !$= $DamageType::Impact && %type !$= $DamageType::Fall && %type !$= $DamageType::Direct && %type !$= $DamageType::Suicide && %type !$= $DamageType::CombatKnife) {
					//Make him slow as hell.
					%data = %this.getDatablock();
					%newspeed = %data.maxForwardSpeed/4;
					%this.setMaxForwardSpeed(%newspeed);
					%this.setMaxBackwardSpeed(%newspeed);
					%this.setMaxSideSpeed(%newspeed);
					%this.setMaxCrouchForwardSpeed(%newspeed);
					%this.setMaxCrouchBackwardSpeed(%newspeed);
					%this.setMaxCrouchSideSpeed(%newspeed);

					%this.dying = 1;
					%this.schedule(1000,damage,%obj,%pos,%amt,%type);
					%this.setDamageFlash(0.75);
					%this.emote(PainMidImage);
					return;
				}
			}
		}
		return Parent::damage(%this, %obj, %pos, %amt, %type);
	}
};
activatePackage(MafiaMadness);