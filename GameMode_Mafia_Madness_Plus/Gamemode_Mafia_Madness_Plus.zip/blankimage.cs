datablock ShapeBaseImageData(BlankImage)
{
	shapeFile = "base/data/shapes/empty.dts";
	mountPoint = 2;
};