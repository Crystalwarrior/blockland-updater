package newMMPackage
{
	//For blood
	function Armor::damage(%this, %obj, %src, %pos, %damage, %type)
	{
		if (getSimTime() - %obj.spawnTime < $Game::PlayerInvulnerabilityTime)
		{
			return Parent::damage(%this, %obj, %src, %pos, %damage, %type);
		}
		if (%pos $= "")
		{
			%pos = %obj.getHackPosition();
		}
		if (%obj.getDamageLevel() + %damage > %this.maxDamage)
		{
			%fatal = true;
		}

		Parent::damage(%this, %obj, %src, %pos, %damage, %type);
		if (%damage <= 0)
		{
			return;
		}

		%time = %obj.getDamagePercent() * 10;
		%time = mClampF(%time, 0, 10);

		%obj.startDrippingBlood(%time);

		if (!%fatal)
		{
			%amt = mClampF(%damage * 0.1, 0, 15);
			%obj.doSplatterBlood(%amt, %pos);
		}
	}

	//For pushing players
	function Player::playThread(%this, %slot, %sequenceName)
	{
		if (%slot != 3)
		{
			Parent::playThread(%this, %slot, %sequenceName);
			return;
		}

		if (%sequenceName $= "activate")
		{
			%eyePoint = %this.getEyePoint();
			%eyeVector = %this.getEyeVector();

			%ray = containerRayCast(%eyePoint,
				vectorAdd(%eyePoint, vectorScale(%eyeVector, 10)),
				$TypeMasks::All, %this
			);

			// if (!%ray || !(%ray.getType() & $TypeMasks::FxBrickObjectType))
			// {
			// 	return;
			// }
		}

		Parent::playThread(%this, %slot, %sequenceName);

		if (%sequenceName !$= "activate2" || $Sim::Time - %this.lastRapidClick < 0.5 || isObject(%this.getMountedImage(0)))
		{
			return;
		}

		%this.lastRapidClick = $Sim::Time;

		%eyePoint = %this.getEyePoint();
		%eyeVector = %this.getEyeVector();

		%ray = containerRayCast(%eyePoint,
			vectorAdd(%eyePoint, vectorScale(%eyeVector, 5)),
			$TypeMasks::PlayerObjectType |
			$TypeMasks::FxBrickObjectType,
			%this
		);

		if (!%ray)
		{
			return;
		}

		%col = getWord(%ray, 0);

		if (!(%col.getType() & $TypeMasks::PlayerObjectType) || %ray.getDataBlock().isPushImmune)
		{
			return;
		}

		%velocity = vectorScale(%this.getForwardVector(), 7);
		%velocity = vectorAdd(%velocity, "0 0 5");

		%col.setVelocity(%velocity);
	}

	function MiniGameSO::reset(%this, %client)
	{
		clearBullets();
		clearDecals();
		Parent::reset(%this, %client);
	}
};
activatePackage(newMMPackage);


function fxDTSBrick::SpawnBullets(%this)
{
	%rnd = getRandom(-3, 7);
	if(%rnd <= 0) return;
	echo("Success!");
	for(%i = 1; %i <= %rnd; %i++)
	{
		%datablock = Bullet357Item;
		%item = new Item()
		{
			dataBlock = %datablock;

			position = %this.getPosition();
		};
		%spread = 15;
		%scalars = getRandomScalar() SPC getRandomScalar() SPC getRandomScalar();
		%spread = vectorScale(%scalars, mDegToRad(%spread / 2));

		%vector = "0 0 10";
		%matrix = matrixCreateFromEuler(%spread);
		%vel = matrixMulVector(%matrix, %vector);
		%item.setVelocity(%vel);
		%position = getWords(%item.getTransform(), 0, 2);
		%item.setTransform(%position SPC eulerToAxis("0 0" SPC getRandom() * 360 - 180));
		if (!isObject(BulletGroup)) {
			MissionCleanup.add(new SimGroup(BulletGroup));
		}
		BulletGroup.add(%item);
		%item.monitorShellVelocity();
		// %item.schedule(14000, fadeOut);
		// %item.schedule(15000, delete);
	}
}

function clearBullets()
{
	if (isObject(BulletGroup)) 
		BulletGroup.deleteAll();
}

function MiniGameSO::pickBrickLoc(%this, %name)
{
	%name = "_" @ %name; //Add dat underscore dog

	if (!BrickGroup_888888.NTObjectCount[%name])
	{
		return;
	}

	%index = getRandom(0, BrickGroup_888888.NTObjectCount[%name] - 1);
	%brick = BrickGroup_888888.NTObject[%name, %index];

	%point = %brick.getTransform();
	%point = setWord(%point, 2, getWord(%brick.getWorldBox(), 5) + 0.1);
	
	return %point;
}