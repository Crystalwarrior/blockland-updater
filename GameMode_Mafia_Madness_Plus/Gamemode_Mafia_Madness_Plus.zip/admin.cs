function serverCmdAdminHelp(%client, %t0, %t1, %t2, %t3, %t4, %t5, %t6, %t7, %t8, %t9, %t10, %t11, %t12, %t13, %t14, %t15, %t16, %t17, %t18, %t19)
{
	for(%i=0;%i<20;%i++) %msg = %msg SPC %t[%i];
	for(%i = 0; %i < clientGroup.getCount(); %i++)
	{
		%cl = clientGroup.getObject(%i);
		if(%cl.isAdmin)
		{
			messageClient(%cl,'',"<font:Arial:22>[!] - \c3Adminhelp from" SPC %client.getSimpleName() @ ":\c6" @ %msg);
		}
	}
	messageClient(%client,'',"<font:Arial:22>\c3You sent an admin message:\c6" @ %msg);
}

function serverCmdAdminPm(%client, %target, %t0, %t1, %t2, %t3, %t4, %t5, %t6, %t7, %t8, %t9, %t10, %t11, %t12, %t13, %t14, %t15, %t16, %t17, %t18, %t19)
{
	for(%i=0;%i<20;%i++) %msg = %msg SPC %t[%i];
	if(!%client.isAdmin) return;

	if(%cl = findClientByName(%target))
	{
		messageClient(%cl,'',"<font:Arial:22>[!] - \c3Admin-PM from" SPC %client.getSimpleName() @ "\c6:" @ %msg);
		messageClient(%client,'',"<font:Arial:22>\c3PMed" SPC %cl.getSimpleName() @ "\c6:" @ %msg);
	}
}