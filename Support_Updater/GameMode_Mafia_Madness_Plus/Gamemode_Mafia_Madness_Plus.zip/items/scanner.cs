datablock ShapeBaseImageData(ScannerImage) {
	shapeFile = "base/data/shapes/printgun.dts";
	doColorShift = true;
	colorShiftColor = "0.2 0.7 0.2 1";
	// eyeOffset = "0 0 0";
	// rotation = eulerToMatrix("90 0 0");
	allowLightKey = true;

	item = ScannerItem;
	armReady = true;

	stateName[0]					= "Activate";
	stateTimeoutValue[0]			= 0.01;
	stateTransitionOnTimeout[0]		= "Ready";

	stateName[1] = "Ready";
	stateAllowImageChange[1] = true;
	stateTransitionOnTriggerDown[1] = "Use";

	stateName[2] = "Use";
	stateScript[2] = "onUse";
	stateAllowImageChange[2] = false;
	stateTransitionOnTriggerUp[2] = "Ready";
};

datablock ItemData(ScannerItem) {
	image = ScannerImage;
	doColorShift = true;
	colorShiftColor = "0.2 0.7 0.2 1";
	shapeFile = "base/data/shapes/printgun.dts";

	uiName = "Forensics Scanner";
	canDrop = false;

	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;
};

function ScannerImage::onMount(%this, %obj, %slot) {
	%obj.client.centerPrint("\c3Fire\c6 to scan. \c3Light key\c6 to view database.", 3);
}

function ScannerImage::onUnMount(%this, %obj, %slot) {
	%obj.client.centerPrint("", 1);
}

function ScannerImage::onUse(%this, %obj, %slot) {
	if (!isObject(%obj.client)) {
		return;
	}

	%eyePoint = %obj.getEyePoint();
	%eyeVector = %obj.getEyeVector();

	%ray = containerRayCast(%eyePoint,
		vectorAdd(%eyePoint, vectorScale(%eyeVector, 6)),
		$TypeMasks::PlayerObjectType | $TypeMasks::FxBrickObjectType,
		%obj
	);

	%col = getWord(%ray, 0);

	if (!isObject(%col)) return;

	if(%col.getType() & $TypeMasks::PlayerObjectType && isObject(%col.client))
	{
		%obj.AddDNAToDatabase(%col);
		return;
	}
	%pos = getWords(%ray, 1, 3);
	initContainerRadiusSearch(
		%pos, 0.4,
		$TypeMasks::ShapeBaseObjectType
	);

	while (isObject( %col = containerSearchNext())) {
		if (%col.isBlood)
		{
			if(isObject(%src = %col.sourceClient))
			{
				if(%src == %obj.client)
				{
					%obj.client.centerPrint("\c2This DNA belongs to the holder of the item.", 2);
					return;
				}
				for(%i = 0; %i < getFieldCount(%obj.DNADatabase); %i++)
				{
					if(getField(%obj.DNADatabase, %i) $= %src.getPlayerName())
					{
						%found = true;
					}
				}
				if(%found)
					%obj.client.centerPrint("\c2DNA\c3" SPC sha1(%src.getPlayerName()) SPC "\n\c2Found in database! This DNA belongs to \n\c3" @ %src.getPlayerName(), 2);
				else
					%obj.client.centerPrint("\c2DNA\c3" SPC sha1(%src.getPlayerName()) SPC "\n\c2Could not be found in the database.", 2);
			}
		}
	}
}

function Player::AddDNAToDatabase(%this, %other)
{
	if(%other.disfigured)
	{
		%this.client.centerPrint("\c2Warning: No DNA found on the target.", 3);
		return;
	}
	if(getWordCount(%this.DNADatabase) <= 0)
	{
		%this.DNADatabase = %other.client.getPlayerName();
		%this.client.centerPrint("\c2DNA\c3" SPC sha1(%other.client.getPlayerName()) SPC "\n\c2Assigned to\c3" SPC %other.client.getPlayerName() @ "!", 3);
		return;
	}
	for(%i = 0; %i < getFieldCount(%this.DNADatabase); %i++)
	{
		if(getField(%this.DNADatabase, %i) $= %other.client.getPlayerName())
		{
			%this.client.centerPrint("\c2DNA\c3" SPC sha1(%other.client.getPlayerName()) SPC "\n\c2Belongs to\c3" SPC %other.client.getPlayerName() @ ".", 3);
			return;
		}
	}
	%this.DNADatabase = %this.DNADatabase @ "\t" @ %other.client.getPlayerName();
	%this.client.centerPrint("\c2DNA\c3" SPC sha1(%other.client.getPlayerName()) SPC "\n\c2Assigned to\c3" SPC %other.client.getPlayerName() @ "!", 3);
}

package ScannerItemPackage
{
	function serverCmdLight(%this)
	{
		%image = %this.player.getMountedImage(0);
		if(%image == nameToID(ScannerImage))
		{
			if(getFieldCount(%this.player.DNADatabase) <= 0)
			{
				%text = "\c2No DNA found in database.";
			}
			else
			{
				%text = "\c2Database contains DNA of\c3:\n";
				for(%i = 0; %i < getFieldCount(%this.player.DNADatabase); %i++)
				{
					if(%i == getFieldCount(%this.player.DNADatabase) - 1)
						%text = %text @ "\c3" @ getField(%this.player.DNADatabase, %i) @ ".";
					else
						%text = %text @ "\c3" @ getField(%this.player.DNADatabase, %i) @ ", ";
				}
			}
			%this.centerPrint(%text, 3);
			return;
		}
		parent::serverCmdLight(%this);
	}
};

activatePackage("ScannerItemPackage");