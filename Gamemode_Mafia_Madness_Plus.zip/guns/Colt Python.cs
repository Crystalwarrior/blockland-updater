datablock ItemData(MMPythonItem : MMgunItem)
{
	shapeFile = "./Colt Python.dts";
	//gui stuff
	uiName = "Colt Python";
	iconName = "Add-Ons/Weapon_Gun/icon_gun";
	doColorShift = true;
	colorShiftColor = "0.762 0.766 0.808 1.000";

	 // Dynamic properties defined by the scripts
	image = MMPythonImage;
	canDrop = true;
	
	//Ammo Guns Parameters
	MMmaxAmmo = 6;
	MMcanReload = 1;
};
datablock ShapeBaseImageData(MMPythonImage : MMgunImage)
{
   // Basic Item properties
   shapeFile = "./Colt Python.dts";
   doColorShift = true;
   colorShiftColor = "0.762 0.766 0.808 1.000";
};

function MMPythonImage::onFire(%this,%obj,%slot){
	MMgunImage::onFire(%this,%obj,%slot);
}
function MMPythonImage::onReady(%this,%obj,%slot) {
	MMgunImage::onReady(%this,%obj,%slot);
}
function MMPythonImage::onReloaded(%this,%obj,%slot) {
	MMgunImage::onReloaded(%this,%obj,%slot);
}
function MMPythonImage::onReloadStart(%this,%obj,%slot) {
	MMgunImage::onReloadStart(%this,%obj,%slot);
}
function MMPythonImage::onReloadMid(%this,%obj,%slot) {
	MMgunImage::onReloadMid(%this,%obj,%slot);
}