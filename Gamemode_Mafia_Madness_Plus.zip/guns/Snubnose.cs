datablock ItemData(MMSnubnoseItem : MMgunItem)
{
	shapeFile = "./Snubnose.dts";

	//gui stuff
	uiName = "Snubnose";
	iconName = "Add-Ons/Weapon_Gun/icon_gun";
	doColorShift = true;
	colorShiftColor = "0.350 0.350 0.350 1.000";

	 // Dynamic properties defined by the scripts
	image = MMSnubnoseImage;
	canDrop = true;
	
	//Ammo Guns Parameters
	MMmaxAmmo = 6;
	MMcanReload = 1;
};
datablock ShapeBaseImageData(MMSnubnoseImage : MMgunImage)
{
   // Basic Item properties
   shapeFile = "./Snubnose.dts";
   doColorShift = true;
   colorShiftColor = "0.350 0.350 0.350 1.000";
};

function MMSnubnoseImage::onFire(%this,%obj,%slot){
	MMgunImage::onFire(%this,%obj,%slot);
}
function MMSnubnoseImage::onReady(%this,%obj,%slot) {
	MMgunImage::onReady(%this,%obj,%slot);
}
function MMSnubnoseImage::onReloaded(%this,%obj,%slot) {
	MMgunImage::onReloaded(%this,%obj,%slot);
}
function MMSnubnoseImage::onReloadStart(%this,%obj,%slot) {
	MMgunImage::onReloadStart(%this,%obj,%slot);
}
function MMSnubnoseImage::onReloadMid(%this,%obj,%slot) {
	MMgunImage::onReloadMid(%this,%obj,%slot);
}