datablock ItemData(SilentCombatKnifeItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./bowie_knife.dts";
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Silenced Combat Knife";
	iconName = "./combatknife";
	doColorShift = true;
	colorShiftColor = "0.6 0.6 0.6 1.000";

	 // Dynamic properties defined by the scripts
	l4ditemtype = "secondary";
	image = SilentCombatKnifeImage;
	canDrop = true;
};

datablock ShapeBaseImageData(SilentCombatKnifeImage)
{
	shapeFile = "./bowie_knife.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0.0 0 0.0";
   rotation = eulerToMatrix("0 0 0");
   eyeOffset = "0";

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = false;

   className = "WeaponImage";

   // Projectile && Ammo.
   item = SilentCombatKnifeItem;
   ammo = " ";
   projectile = hammerProjectile;
   projectileType = Projectile;

   //melee particles shoot from eye node for consistancy
   melee = true;
   doRetraction = false;
   //raise your arm up or not
   armReady = true;

   //casing = " ";
   doColorShift = true;
   colorShiftColor = SilentCombatKnifeItem.colorShiftColor;
   
   raycastEnabled = 1;
   raycastRange = 4;
   raycastHitExplosion = hammerProjectile;
   raycastHitPlayerExplosion = "";

   directDamage = 105;
   directDamageType = $DamageType::combatknife;

   // raycastSpread = 0;
   raycastCount = 1;
   
   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]			= "Activate";
	stateTimeoutValue[0]		= 0.2;
	stateTransitionOnTimeout[0]	= "StabCooldown";
	stateSequence[0]		= "Activate";
	//stateSound[0]					= weaponSwitchSound;

	stateName[1]			= "Ready";
	stateTransitionOnTriggerDown[1]	= "Charge";
	stateScript[1]                  = "onReady";
	stateAllowImageChange[1]	= true;
	
	stateName[2]                    = "Charge";
	stateTransitionOnTimeout[2]	= "Armed";
	stateTimeoutValue[2]            = 0.4;
	stateWaitForTimeout[2]		= false;
	stateTransitionOnTriggerUp[2]	= "AbortCharge";
	stateSequence[2]		= "Prime";
	stateScript[2]                  = "onCharge";
	stateAllowImageChange[2]        = false;
	
	stateName[3]			= "AbortCharge";
	stateTransitionOnTimeout[3]	= "StabCooldown";
	stateTimeoutValue[3]		= 0.1;
	stateWaitForTimeout[3]		= true;
	stateEmitterNode[3]			= "tipNode";
	stateSequence[3]		= "Swing";
	stateEmitter[3]			= combatKnifeEmitter;
	stateEmitterTime[3]			= 0.17;
	stateScript[3]			= "onStabfire";
	stateSound[3]				= knifeFireSound;
	stateAllowImageChange[3]	= false;

	stateName[4]			= "Armed";
	stateTransitionOnTriggerUp[4]	= "Fire";
	stateAllowImageChange[4]	= false;
	stateScript[4]                  = "onCharge";

	stateName[5]			= "Fire";
	stateTransitionOnTimeout[5]	= "Stabcooldown";
	stateTimeoutValue[5]		= 0.4;
	stateEmitter[5]			= combatKnifeEmitter;
	stateEmitterTime[5]			= 0.289;
	stateEmitterNode[5]			= "tipNode";
	stateFire[5]			= true;
	stateSequence[5]		= "swipe";
	stateScript[5]			= "onFire";
	stateWaitForTimeout[5]		= true;
	stateAllowImageChange[5]	= false;
	//stateSound[5]				= knifeFireSound;

	stateName[6]			= "StabCooldown";
	stateTransitionOnTimeout[6]	= "Ready";
	stateTimeoutValue[6]		= 0.1;
	stateWaitForTimeout[6]		= true;
	stateSequence[6]		= "Prime";
	stateAllowImageChange[6]	= false;
};

function SilentCombatKnifeImage::onFire(%this, %obj, %slot)
{
	%obj.playThread(2,shiftto);
	%obj.playThread(3,spearthrow);
	%obj.playThread(4,shiftdown);
	%obj.playThread(5,shiftdown);
	%obj.playThread(6,shiftdown);

	%masks = $TypeMasks::FxBrickObjectType |
		 $TypeMasks::PlayerObjectType |
		  $TypeMasks::StaticObjectType |
		   $TypeMasks::TerrainObjectType |
		    $TypeMasks::VehicleObjectType;
	%ray = containerRayCast(
		%obj.getEyePoint(),
		vectorAdd(%obj.getEyePoint(), vectorScale(%obj.getEyeVector(), 4)),
		%masks, %obj
	);

	if (!%ray)
	{
		return;
	}

	if(%ray.getType() & $Typemasks::PlayerObjectType)
		%ray.damage(%obj, getWords(%ray, 1, 3), 105, %this.directDamageType);
}

function SilentCombatKnifeImage::onStabFire(%this, %obj, %slot)
{
	%obj.playThread(2,shiftto);
	%obj.playThread(3,shiftdown);

	%masks = $TypeMasks::FxBrickObjectType |
		 $TypeMasks::PlayerObjectType |
		  $TypeMasks::StaticObjectType |
		   $TypeMasks::TerrainObjectType |
		    $TypeMasks::VehicleObjectType;
	%ray = containerRayCast(
		%obj.getEyePoint(),
		vectorAdd(%obj.getEyePoint(), vectorScale(%obj.getEyeVector(), 4)),
		%masks, %obj
	);

	if (!%ray)
	{
		return;
	}

	if(%ray.getType() & $Typemasks::PlayerObjectType)
	{
		%ray.damage(%obj, getWords(%ray, 1, 3), 105, %this.directDamageType);
		if(%ray.getState() !$= "Dead")
			return;

		if(%ray.disfigured) {
			messageClient(%client,'',"\c4That corpse is already unrecognizable!");
			return;
		}
		messageClient(%client,'',"\c4You have made the corpse of\c3" SPC %ray.name SPC "\c4unrecognizable.");
		%ray.name = "disfigured corpse";
		%ray.job = "permanently retired";
		%ray.disfigured = 1;
	}
}

function WeaponImage::onHitObject(%this,%obj,%slot,%col,%pos,%normal,%shotVec,%crit)
{
	parent::onHitObject(%this,%obj,%slot,%col,%pos,%normal,%shotVec,%crit);
}