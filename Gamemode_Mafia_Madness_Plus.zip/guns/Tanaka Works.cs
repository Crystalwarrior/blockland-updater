datablock ItemData(MMTanakaItem : MMGunItem)
{
	shapeFile = "./Tanaka Works.dts";

	//gui stuff
	uiName = "Tanaka Works";
	iconName = "Add-Ons/Weapon_Gun/icon_gun";
	doColorShift = true;
	colorShiftColor = "0.750 0.750 0.750 1.000";

	 // Dynamic properties defined by the scripts
	image = MMTanakaImage;
	canDrop = true;
	
	//Ammo Guns Parameters
	MMmaxAmmo = 6;
	MMcanReload = 1;
};
datablock ShapeBaseImageData(MMTanakaImage : MMgunImage)
{
   // Basic Item properties
   shapeFile = "./Tanaka Works.dts";
   doColorShift = true;
   colorShiftColor = "0.750 0.750 0.750 1.000";
};
function MMTanakaImage::onFire(%this,%obj,%slot){
	MMgunImage::onFire(%this,%obj,%slot);
}
function MMTanakaImage::onReady(%this,%obj,%slot) {
	MMgunImage::onReady(%this,%obj,%slot);
}
function MMTanakaImage::onReloaded(%this,%obj,%slot) {
	MMgunImage::onReloaded(%this,%obj,%slot);
}
function MMTanakaImage::onReloadStart(%this,%obj,%slot) {
	MMgunImage::onReloadStart(%this,%obj,%slot);
}
function MMTanakaImage::onReloadMid(%this,%obj,%slot) {
	MMgunImage::onReloadMid(%this,%obj,%slot);
}