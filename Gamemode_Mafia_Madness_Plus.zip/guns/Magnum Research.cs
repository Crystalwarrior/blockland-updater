datablock ItemData(MMResearchBFRItem : MMgunItem)
{
	shapeFile = "./Research BFR.dts";

	//gui stuff
	uiName = "Research BFR";
	iconName = "Add-Ons/Weapon_Gun/icon_gun";
	doColorShift = true;
	colorShiftColor = "0.140 0.140 0.190 1.000";

	 // Dynamic properties defined by the scripts
	image = MMResearchBFRImage;
	canDrop = true;
	
	//Ammo Guns Parameters
	MMmaxAmmo = 6;
	MMcanReload = 1;
};
datablock ShapeBaseImageData(MMResearchBFRImage : MMgunImage)
{
   // Basic Item properties
   shapeFile = "./Research BFR.dts";
   doColorShift = true;
   colorShiftColor = "0.140 0.140 0.190 1.000";
};

function MMResearchBFRImage::onFire(%this,%obj,%slot){
	MMgunImage::onFire(%this,%obj,%slot);
}
function MMResearchBFRImage::onReady(%this,%obj,%slot) {
	MMgunImage::onReady(%this,%obj,%slot);
}
function MMResearchBFRImage::onReloaded(%this,%obj,%slot) {
	MMgunImage::onReloaded(%this,%obj,%slot);
}
function MMResearchBFRImage::onReloadStart(%this,%obj,%slot) {
	MMgunImage::onReloadStart(%this,%obj,%slot);
}
function MMResearchBFRImage::onReloadMid(%this,%obj,%slot) {
	MMgunImage::onReloadMid(%this,%obj,%slot);
}