$MMGameModes = -1;
$MMGameModeName[$MMGameModes++] = "Standard";
$MMGameModeName[$MMGameModes++] = "Classic";
$MMGameModeName[$MMGameModes++] = "I Hate You All";
$MMGameModeName[$MMGameModes++] = "hahahahahahahahahahahaha";
$MMGameModeName[$MMGameModes++] = "Just Try to Survive";
$MMGameModeName[$MMGameModes++] = "Abduct Titanium Tonight";
$MMGameModeName[$MMGameModes++] = "brackets, think of the name -ottosparks (6)";

$MMGameTypes = -1;
$MMGameTypeName[$MMGameTypes++] = "None";
$MMGameTypeName[$MMGameTypes++] = "One In the Chamber";

function serverCmdManualRole(%client, %player, %role)
{
	if(!%client.isSuperAdmin)
		return;
	%player = findClientByName(%player);
	%n = %player.getPlayerName();
	%player.manualRole = %role;
}

function serverCmdRole(%client, %player, %role)
{
	if(!%client.isSuperAdmin)
		return;
	%player = findClientByName(%player);
	%n = %player.getPlayerName();
	%player.role = %role;
}

function serverCmdSetIgnore(%client, %player, %i)
{
	if(!%client.isSuperAdmin && !%client.isAdmin)
		return;
	%player = findClientByName(%player);
	%n = %player.getPlayerName();
	if(%i $= "")
		%player.MMIgnore = !%player.MMIgnore;
	else
		%player.MMIgnore = %i;
	
	if(%player.MMIgnore)
		messageAll('', "\c3" @ %n SPC "\c1is no longer being included in Mafia Madness games.");
	else
		messageAll('', "\c3" @ %n SPC "\c1is now being included in Mafia Madness games.");
}

function serverCmdSetGameMode(%client, %mode)
{
	if(!%client.isSuperAdmin)
		return;
	if(%mode > $MMGameModes)
	{
		messageClient(%client, '', "\c1OUT OF RANGE");
		return;
	}
	if(!%mode || %mode <= -1)
		%mode = 0;
	messageAll('', "\c1Mafia Madness game mode set to \c3" @ $MMGameModeName[$MMGameMode = %mode] @ "\c1.");
}

function serverCmdSetGameType(%client, %mode)
{
	if(!%client.isSuperAdmin)
		return;
	if(%mode > $MMGameTypes)
	{
		messageClient(%client, '', "\c1OUT OF RANGE");
		return;
	}
	if(!%mode || %mode <= -1)
		%mode = 0;
	messageAll('', "\c1Mafia Madness game type set to \c3" @ $MMGameTypeName[$MMGameType = %mode] @ "\c1.");
}

function serverCmdManualGame(%client, %i)
{
	if(!%client.isSuperAdmin)
		return;
	$MMManualGame = (%i $= "" ? !$MMManualGame : %i);
}

function serverCmdReqInfo(%client, %targ, %type, %flag)
{
	if(!%client.isAdmin && !%client.isSuperAdmin)
		return;
	%targ = findClientByName(%targ);
	switch(%type)
	{
		case 0: commandToClient(%client, 'MMRecInfo', %type, %targ.MMIgnore, %flag);
		case 1: commandToClient(%client, 'MMRecInfo', %type, %targ.manualRole, %flag);
		case 2: commandToClient(%client, 'MMRecInfo', %type, %targ.role, %flag);
		case 3: commandToClient(%client, 'MMRecInfo', %type, $MMManualGame, %flag);
	}
}