datablock audioDescription(audioDistant3d : audioClose3D) {
	maxDistance = 100;
	referenceDistance = 25;
	volume = 1.2;
};
datablock audioProfile(smmGunDistantSound1) {
	fileName = "./sounds/Reflection_Distant-01.wav";
	description = audioDistant3d;
	preload = true;
};
datablock audioProfile(smmGunDistantSound2) {
	fileName = "./sounds/Reflection_Distant-02.wav";
	description = audioDistant3d;
	preload = true;
};
datablock audioProfile(smmGunDistantSound3) {
	fileName = "./sounds/Reflection_Distant-03.wav";
	description = audioDistant3d;
	preload = true;
};

datablock audioDescription(audioFar3d : audioClose3D) {
	maxDistance = 200;
	referenceDistance = 60;
	volume = 1.1;
};
datablock audioProfile(smmGunFarSound1) {
	fileName = "./sounds/Reflection_Far-01.wav";
	description = audioFar3d;
	preload = true;
};
datablock audioProfile(smmGunFarSound2) {
	fileName = "./sounds/Reflection_Far-02.wav";
	description = audioFar3d;
	preload = true;
};
datablock audioProfile(smmGunFarSound3) {
	fileName = "./sounds/Reflection_Far-03.wav";
	description = audioFar3d;
	preload = true;
};