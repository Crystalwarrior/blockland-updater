function redruls(%n)
{
	if(!isObject(%n))
		%n = findClientByName(%n);
	talk("R:" SPC %n.rules);
	for(%i = 1; %i <= 7; %i++)
		talk(%i SPC %n.rules[%i]);
}

function serverCmdRedRuls(%client, %n, %old)
{
	%oldn = %n;
	%n = findClientByName(%n);
	if(!isObject(%n) && isObject(findClientByBL_ID(%oldn)))
		%n = findClientByBL_ID(%oldn);
	%b = %n.bl_id;
	if(!%client.isAdmin)
	{
		messageClient(%client, '', "<font:impact:24><shadow:-2:-2><shadowcolor:000000>GAME OVER GAME OVER DINO LOSER DINO LOSER");
		return;
	}
	if(!isObject(%n) && !$MMReadRules[%oldn])
	{
		messageClient(%client, '', "\c6This player has no client/record!");
		return;
	}
	if($MMReadRules[%oldn])
		%b = %oldn;
	if(%old)
	{
		messageClient(%client, '', "\c6R:" SPC %n.rules SPC "\c7" @ $MMReadRules[%b]);
		for(%i = 1; %i <= 7; %i++)
			messageClient(%client, '', "\c6" @ %i SPC %n.rules[%i] SPC "\c7" @ $MMReadRules[%b, %i]);
		return;
	}
	messageClient(%client, '', (%n.rules ?
				    "\c3" @ %n.getPlayerName() SPC "\c6has done \c3/rules \c5and read these categories\c6..." :
				    (!$MMReadRules[%b] ? "\c3" @ %n.getPlayerName() SPC "\c6has not done \c3/rules\c6!" :
				    "\c6BL_ID\c3" SPC %b SPC "\c6has done \c3/rules \c5at some point and read these categories\c6...")));
	if(!%n.rules && !$MMReadRules[%b])
		return;
	for(%i = 1; %i <= 7; %i++)
		%str = %str @ (%n.rules[%i] ? " " @ %i : "");
	%str = %str @ "\c7";
	for(%i = 1; %i <= 7; %i++)
		%str = %str @ ($MMReadRules[%b, %i] ? " " @ %i : "");
	messageClient(%client, '', "\c6" @ trim(%str));
}

function highestPing()
{
	for(%i = 0; %i < clientGroup.getCount(); %i++)
	{
		%c = clientGroup.getObject(%i);
		if(%c.getPing() > %highestPing)
		{
			%highestPing = %c.getPing();
			%highestPingName = %c.getPlayerName();
		}
	}
	return %highestPingName SPC %highestPing;
}