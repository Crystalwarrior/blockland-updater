//This file exists to overwrite some of the functions for external addons
// deactivatePackage(ComplexFirearmsPackage);
package ComplexFirearmsPackage
{
	function Armor::onDisabled(%this, %obj, %disabled)
	{
		if(%obj.bullets["357"] > 0 && $MMDropBulletsOnDeath && ($MMGameType != 1 || !$DefaultMinigame.MMGame)) //Check whether or not the game allows bullet drop on death and if it's not one in the chamber gametype
		{
			for(%i = 0; %i < %obj.bullets["357"]; %i++)
			{
				%datablock = Bullet357Item;
				%item = new Item()
				{
					dataBlock = %datablock;
					position = %obj.getEyePoint();
				};
				%spread = 30;
				%scalars = getRandomScalar() SPC getRandomScalar() SPC getRandomScalar();
				%spread = vectorScale(%scalars, mDegToRad(%spread / 2));

				%vector = "0 0 10";
				%matrix = matrixCreateFromEuler(%spread);
				%vel = matrixMulVector(%matrix, %vector);
				%item.setVelocity(%vel);
				%position = getWords(%item.getTransform(), 0, 2);
				%item.setTransform(%position SPC eulerToAxis("0 0" SPC getRandom() * 360 - 180));
				if (!isObject(BulletGroup)) {
					MissionCleanup.add(new SimGroup(BulletGroup));
				}
				BulletGroup.add(%item);
				if(!$DefaultMinigame.MMGame)
				{
					%item.schedule(14000, fadeOut);
					%item.schedule(15000, delete);
				}
			}
		}
		parent::onDisabled(%this, %obj, %disabled);
	}
};
// activatePackage(ComplexFirearmsPackage);

function revolverImage::onMount(%this, %obj, %slot)
{
	parent::onMount(%this,%obj,%slot);
	%pass = ($MMGameType == 1) && $DefaultMinigame.MMGame; //Check whether or not there's a round running as well as whether or not it's the One in the Chamber gametype
	if(%obj.currRevolverSlot $= "")
		%obj.currRevolverSlot = 0;
	if(%obj.bullets["357"] $= "")
		%obj.bullets["357"] = %pass ? 1 : getRandom(0, 16);
	for(%i = 0; %i <= 5; %i++)
	{
		if(%obj.revolverBullet[%i] $= "")
			%obj.revolverBullet[%i] = %pass ? 0 : getRandom(0, 1) * 2;	//This sets the first slot of chamber to 1 if the gametype is One in the Chamber.
																									//It also sets the rest of the slots to 0.
	}
}