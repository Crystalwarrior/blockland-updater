datablock ItemData(mCuff_CuffsItem:PrintGun)
{
	uiname = "Hand Cuffs";
	shapefile = "./HandCuffItem.dts";
	image=mCuff_CuffsImage;
	colorShiftColor = "0.7 0.7 0.7 1";
	iconName = "";
};
datablock ShapeBaseImageData(mCuff_CuffsImage:PrintGunImage)
{
	eyeOffset = "";
	shapeFile = "./handCuffItem.dts";
	stateEmitter[2] = "";
	stateSound[2] = "";
	showbricks=0;
};
datablock ItemData(mCuff_KeyItem:PrintGun)
{
	uiname = "Hand Cuffs Keys";
	shapefile = "./HandCuffKey.dts";
	image=mCuff_KeyImage;
	colorShiftColor = "0.7 0.7 0.7 1";
	iconName = "";
};
datablock ShapeBaseImageData(mCuff_KeyImage:PrintGunImage)
{
	eyeOffset = "";
	shapeFile = "./handCuffKey.dts";
	stateEmitter[2] = "";
	stateSound[2] = "";
	showbricks=0;
};
datablock ShapeBaseImageData(mCuff_EquipImage:printGunImage)
{
	shapeFile = "./handCuffEquip.dts";
	mountPoint = 0;
	armReady=1;
	showbricks=0;
	offset = "0.07 0 0";
	colorShiftColor = "0.7 0.7 0.7 1";
	stateSound[2]="";
	stateEmitter[2]="";
};