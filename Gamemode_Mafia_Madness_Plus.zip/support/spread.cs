function spreadVector(%vector, %spread)
{
	%scalars = randomScalar() SPC randomScalar() SPC randomScalar();
	%scalars = vectorScale(%scalars, mDegToRad(%spread));

	return matrixMulVector(matrixCreateFromEuler(%scalars), %vector);
}

function randomScalar()
{
	return getRandom() * 2 - 1;
}
//wat lol
function vectorSpread(%vector, %spread) {
	%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
	%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
	%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;

	%mat = matrixCreateFromEuler(%x SPC %y SPC %z);
	return vectorNormalize(matrixMulVector(%mat, %vector));
}