datablock playerData(CorpsePlayer : PlayerNoJet)
{
	boundingBox = "5 5 4";
	uiName = "";
};

// $Pref::Server::MMDumpsterLoc = "-9.83219 -152.837 0.202533"; //Change a brick's name to abductpoint instead
$Pref::Server::MMAfterlifeLoc = "1211.73 135.093 0.202098";
$FOOTSTEPS_BLOODYFOOTPRINTS = true;
$m = "concrete"; //Set default footstep material to concrete.
// exec("./sounds.cs");
// exec("./support_ammoguns.cs");
exec("./client.cs");
exec("./support/decals.cs");
exec("./support/spread.cs");
exec("./support/raycasts.cs");
exec("./blankimage.cs");
exec("./guns/Silent Combat Knife.cs");
exec("./new.cs");
exec("./blood/blood.cs");

exec("./items/scanner.cs");
// exec("./guns/MMGun.cs");
// exec("./guns/Snubnose.cs");
// exec("./guns/Magnum Research.cs");
// exec("./guns/Colt Python.cs");
// exec("./guns/Tanaka Works.cs");

exec("./Murder.cs");
exec("./ottoscripts.cs");
exec("./Hook.cs");
exec("./overwritePackage.cs");
exec("./admin.cs");
prepMM();